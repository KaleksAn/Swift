import UIKit
import Foundation

let xwq = """
Text text
Text textText

Text textText text
Text textText textText text
Text textText textText textText text
Text textText textText textText textText text
Text textText textText textText textText textText text
Text textText textText textText textText textText textText text
Text textText textText textText textText textText textText textText text
Text textText textText textText textText textText textText textText textText text
"""





let softWrappedQuotation = """
The White Rabbit put on his spectacles.  "Where shall I begin,\
please your Majesty?" he asked.

"Begin at the beginning," the King said gravely, "and go on\
till you come to the end; then stop."
"""



let lineBreaks = """

       This string starts with a line break.
           It also ends with a line break.
           Test Test test

       """


print(lineBreaks)



let kor = "Test \r\r\r Rest tre"
print(kor)



let threeDoubleQuotationMarks = """
Escaping the first quotation mark \"""
Escaping all three quotation marks \"\"\"
"""
print(threeDoubleQuotationMarks)




let threeMoreDoubleQuotationMarks = #"""
Here are three more double quotes: """
"""#

print(threeMoreDoubleQuotationMarks)




let emptyString = String()

if emptyString.isEmpty {
    print("String is empty")
} else {
    print("String have value")
}




let dollarSign = "\u{24}"        // $,  Unicode scalar U+0024
let blackHeart = "\u{2665}"      // ♥,  Unicode scalar U+2665
let sparklingHeart = "\u{1F496}" // 💖, Unicode scalar U+1F496



let badStart = """
One
Two
"""

let end = "Three"


print("\(badStart + end)")

let goodStart = """
One
Two

"""


print("\(goodStart + end)")








//Доступ к строке и ее изменение


let eAcute: Character = "\u{E9}"
let combinedEAcute: Character = "\u{65}\u{301}"

let precomposed: Character = "\u{D55C}"
let decompozed: Character = "\u{1112}\u{1161}\u{11AB}"
let enclosedEAcue: Character = "\u{E9}\u{20DD}"


let unusualMenagerie = "Hello World! Camel, Lion"
print("unusualMenagerie have \(unusualMenagerie.count) symbols")



let greeting = "Guten Tag!"
greeting[greeting.startIndex]

greeting[greeting.index(before: greeting.endIndex)]
greeting[greeting.index(after: greeting.startIndex)]

let index = greeting.index(greeting.startIndex, offsetBy: 7)

//greeting[greeting.endIndex]

for index in greeting.indices {
    print("\(greeting[index])", terminator: " ")
    print(greeting)
}



var welcome = "Hello"
welcome.insert("!", at: welcome.endIndex)
welcome.insert(contentsOf: " there", at: welcome.index(before: welcome.endIndex))

welcome.remove(at: welcome.index(before: welcome.endIndex))

let range = welcome.index(welcome.endIndex, offsetBy: -6)..<welcome.endIndex
welcome.removeSubrange(range)


welcome.count

let fgh = "кенш"

let newStry = fgh 


newStry.count

(newStry as NSString).length
print("\u{21a2}\u{2b0b}")
let newSymbol: Character = "a\u{20dd}\u{0301}"

fgh.count



for i in fgh {
    print(i)
}



// Task 01

let var01 = "11l"
let var02 = "2O2"
let var03 = "548"
let var04 = "1923"
let var05 = "OO10"
let var06 = "303"

var sum = 0

let varInt01 = Int(var01) ?? 0
let varInt02 = Int(var02) ?? 0
let varInt03 = Int(var03) ?? 0
let varInt04 = Int(var04) ?? 0
let varInt05 = Int(var05) ?? 0
let varInt06 = Int(var06) ?? 0

var str01 = Int(var01) != nil ? var01 : "nil"
var str02 = Int(var02) != nil ? var02 : "nil"
var str03 = Int(var03) != nil ? var02 : "nil"
var str04 = Int(var04) != nil ? var04 : "nil"
var str05 = Int(var05) != nil ? var05 : "nil"
var str06 = Int(var06) != nil ? var06 : "nil"





sum = varInt01 + varInt02 + varInt03 + varInt04 + varInt05 + varInt06


print("\(varInt01) + \(varInt02) + \(varInt03) + \(varInt04) + \(varInt05) + \(varInt06) = \(varInt01 + varInt02 + varInt03 + varInt04 + varInt05 + varInt06) or \(sum)")

print(str01 +  str02 +  str03 +  str04 +  str05 + str06 + " = " + String(sum))


//Task 02

let uniCode01 = "\u{1112}\u{1161}\u{11AB}"
let uniCode02 = "\u{E9}\u{20DD}"
let uniCode03 = "\u{1F496}"
let uniCode04 = "\u{11BE}"
let uniCode05 = "\u{24}"
let combine = "\u{1f44d}\u{1f3fd}"
let thumbsUp = "\u{1f44d}"
let multiplier = "qweeqew"
var indexLetter = multiplier.startIndex
print(indexLetter)


let mixSimbols = "\u{1112}\u{1161}\u{11AB}\u{E9}\u{20DD}\u{1F496}\u{11BE}\u{1f44d}\u{1f3fd}\u{1f44d}"
mixSimbols.count
(mixSimbols as NSString).length

uniCode01.count
(uniCode01 as NSString).length
uniCode02.count
uniCode02.unicodeScalars.count
(uniCode02 as NSString).length






/*let firstCharIndex = abc.startIndex
let fourthCharIndex = abc.index(firstCharIndex, offsetBy: 5)
let subAbc = abc[firstCharIndex...fourthCharIndex]
subAbc
type(of:subAbc)


let subStr = abc[fourthCharIndex...]
subStr

*/


let abc = "abcdefghijklmnopqrstuvwxyz"
var countLetter = 0
let findLetter: Character = "z"
//1 method
for i in abc {
    if findLetter == i {
        print("Symbol \(findLetter) have index \(countLetter)")
        countLetter = 0
        
    } else if findLetter != i && countLetter >= 26 {
        print("Incorrect value")
    }
    countLetter = countLetter + 1
}


// method 2

if abc.contains(findLetter) {
    print("Number of \(findLetter): \(abc.distance(from: abc.startIndex, to: abc.firstIndex(of: findLetter)!))")
} else {
    print("Not have value")
}

let array = [("March", 31), ("April", 30)]
array.count
