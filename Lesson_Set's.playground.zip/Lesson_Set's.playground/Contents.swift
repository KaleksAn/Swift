

//Create empty set's

let setOne = Set<String>()
let setTwo: Set<String> = []
var setThree: Set = [1, 2, 3, 4]

setThree.insert(5)
setThree.insert(6)
setThree.insert(7)

setThree.isEmpty
setThree.count
setThree.remove(6)
setThree

let boolValue = setThree.contains(1)
boolValue


let setFromOneToThree: Set = [1, 2, 3]
var setFromFourToNine: Set = [1, 2, 4, 5, 6, 7, 8, 9, 9, 7, 2, 5, 5, 3]

let allValuesArray = setFromOneToThree.union(setFromFourToNine).sorted()
let commonValuesSet = setFromOneToThree.intersection(setFromFourToNine)


let notRepeatedValuesArray = setFromOneToThree.symmetricDifference(setFromFourToNine).sorted()

let substractedValuesArray = setFromOneToThree.subtracting(setFromFourToNine).sorted()


var setFilter: Set<Int> = []

for i in setFromFourToNine {
    setFilter.insert(i)
}

setFromFourToNine = setFilter
setFromFourToNine.sorted()


var sortArray: Set<Int> = Set<Int>(setFromFourToNine)

setFromFourToNine = sortArray
setFromFourToNine.sorted()




let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let differentDigits: Set = [3, 4, 7, 8]

let inter = differentDigits.intersection(oddDigits)


let exclusive = differentDigits.symmetricDifference(oddDigits)
exclusive

let union = evenDigits.union(oddDigits)
union.sorted()
type(of: union)

let subtract = differentDigits.subtracting(evenDigits)



let aSet: Set = [1, 2, 3, 4, 5]
let bSet: Set = [1, 3]
let cSet: Set = [5, 6, 7, 8]

let copyOfBSet = bSet
bSet == copyOfBSet

//Проверка на подмножество
bSet.isSubset(of: aSet)


//Проверка на надмножество
aSet.isSuperset(of: bSet)

bSet.isDisjoint(with: cSet)

bSet.isStrictSubset(of: aSet)
aSet.isStrictSuperset(of: bSet)

let setOfNums: Set = [1, 10, 2, 5, 12, 23]
let sortedArray = setOfNums.sorted()
sortedArray
type(of: sortedArray)


var setTest: Set = ["2", "we"]

for i in setTest {
    print("Value \(type(of: i))")
}

setTest = ["5"]


print(setTest)
setTest.insert("wewe")


var werter = ["Test1": 234, "Test2": 5632]
werter["Test3"] = 43465
werter
