import UIKit

//Homework for the Swift developers group

//Task 01
/*
 Создать 3 функции 1 которая ничего не принимает и ничего не возвращает. 2)Принимает но не возвращает. 3)И принимает и возвращает = и все три вызвать потом
 */

//1 Empty function's

func emptyFunc() {
    //empty func
}

func firstFunc() {
    print("This is my first function!")
}



//2 Function's with parameter's
func secondFunction(name: String, age: Int = 1) {
    print("Info for student: \nName \(name), age \(age)")
}


func enterInfo(ask: String, answer: Bool = false) {
    if ask.isEmpty {
        print("Answer is \(answer)")
    } else {
        print("Answer is \(!answer)")
    }
}

secondFunction(name: "Jack", age: 23)
enterInfo(ask: "")



//3 Function's with parameter's and return value's

func sum(var1: Int = 0, var2: Int = 0) -> Int {
    
    let result = var1 + var2
    return result
}

let callSum = sum(var1: 23, var2: 77)
print("Sum result eequal: \(callSum)")

func funcWithTuple(coordinate: (a: Int, b: Int), bool: Bool) -> (a: Int, b:Int, message: String) {
    if coordinate.a == coordinate.b {
        return (coordinate.a, coordinate.b, "Coordinate's is equal!")
    } else if coordinate.a != coordinate.b {
        return (coordinate.a, coordinate.b, "Coordinate's is not equal!")
    }
    return (0, 0, "Is empty tuple")
}

funcWithTuple(coordinate: (23, 23), bool: true)
let refernceFunc = funcWithTuple(coordinate: (23, 31), bool: true)
refernceFunc.a
refernceFunc.b
refernceFunc.message

//Call is all functions
emptyFunc()
secondFunction(name: "Dima", age: 22)
funcWithTuple(coordinate: (34, 99), bool: true)


// Call 3 function's

func allFunctions(first: () -> (), second: (String, Int) -> (), third: Bool) -> (_ num1: Int, _ num2: Int) -> Int {
    
        firstFunc()
        secondFunction(name:"Alex", age: 22)
   
    return sum
}


let testets = allFunctions(first: emptyFunc, second: secondFunction, third: false)
testets (23, 432)







//Task 02

/*
 Создать журнал для учителя который будет принимать имя студента , профессию и оценку и записывает это все в массив.И внесите 10 студентов туда и распечатаете через цикл for
 */

var studentsList: [String] = []

func enterInfoStudent(name: String, professional: String, rating: Int) {
    let student = "Name student: \(name).  Professional: \(professional).  Rating: \(rating)"
    studentsList.append(student)
}

enterInfoStudent(name: "Aleksandr", professional: "iOS developer", rating: 8)
enterInfoStudent(name: "Dmitriy", professional: "Electrician", rating: 8)
enterInfoStudent(name: "Andrey", professional: "Factory worker", rating: 9)
enterInfoStudent(name: "Vladimir", professional: "Factory worker", rating: 10)
enterInfoStudent(name: "Sergey", professional: "IoT Developer", rating: 7)
enterInfoStudent(name: "Aleksey Skutarenko", professional: "Master and teacher iOS dev", rating: 10)
enterInfoStudent(name: "Roman", professional: "Workerman", rating: 6)
enterInfoStudent(name: "Vovchik", professional: "Workerman", rating: 6)
enterInfoStudent(name: "Stanislav", professional: "Factory worker", rating: 8)
enterInfoStudent(name: "Boris", professional: "Worker", rating: 5)


studentsList.sort()
//Print 1
for student in studentsList {
    
    print(student)
}


//Print 2
print("\nSecond print array")
for index in 0..<studentsList.count {
    if index % 2 == 0 {
    print(studentsList[index])
    }
}


//Task 03
/*
 Создать функцию которая принимает имя и фамилию, потом положить это в массив и отсортировать и вывести результат в консоль :)
 */
print("\nTask 03")
print("Variant 1")

//Var 1
var userName = [String]()

func usersAndName (name: String, surname: String) {
    userName.append(name + surname)
    userName.sort()
}

usersAndName(name: "Dmitriy", surname: "Kim")
usersAndName(name: "Alex", surname: "Kan")

for student in userName.sorted() {
    print(student)
}


//Var 2
print("\nVariant 2")

userName.removeAll()

func addUsers(name: String?, surname: String?) -> String {
    
    if name == nil && surname == nil {
        return "Value nil"
    }
    
    let fullName = "\(surname!) \(name!)"
    userName.append(fullName)
    userName.sort()
    
    guard userName.isEmpty != true else {
        return "Empty array"
    }
    
    return "Function is finished!"
}


addUsers(name: "Vovchik", surname: "Ten")
addUsers(name: "Vika", surname: "Tsoy")
addUsers(name: "Karina", surname: "Kim")

for user in userName {
    print("Name user: \(user)")
}



//Task 04
//Создайте функцию которая принимает параметры и вычисляет площадь круга

//Var 1
print("\nTask 04")
print("Variant 1")
func area(radius: Double) -> Double {
    let r = pow(radius, 2.0)
    let square = r * 3.14
    
    return square
}

let squareCircle = area(radius: 4)
print("Area circle equal: \(squareCircle)")


//Var 2
print("Variant 2")

func calcArea(inRadius r: Double) -> Double {
    var radiusSq = r
    for _ in 1...2 {
        radiusSq *= 2.0
    }
    
    let square = radiusSq * 3.14
    return square
}


let resultCalc = calcArea(inRadius: 4)
print("Square in circle: \(resultCalc)")



//Task 05
/*
 Создайте Dictionary , с именем ученики , где ключ name и score , а значение (1 тюпл из 5 имен) и (второй тюпл из 5 оценок).И распечатайте только именна по ключу
 */

print("\nTask 05")
var sampleDict = [String: ((String, String, String, String, String),(Int, Int, Int, Int, Int))]()

func funcForDict(key: (String, Int), valueForTuple1: (String, String, String, String, String), ratingTuple: (Int, Int, Int, Int, Int)) {
    sampleDict["\(key.0) \(key.1)"] = ((valueForTuple1.0, valueForTuple1.1, valueForTuple1.2, valueForTuple1.3, valueForTuple1.4), (ratingTuple.0, ratingTuple.1, ratingTuple.2, ratingTuple.3, ratingTuple.4))
}



funcForDict(key: ("Igor", 22), valueForTuple1: ("Igor", "Vova", "Den", "Tima", "Dima"), ratingTuple: (23, 22, 30, 34, 12))

for key in sampleDict.keys {
    print(sampleDict[key] ?? "No value")
}

//
let newDict = ["name": ("Igor", "Vova", "Misha", "Slava", "Kolya"), "Score": (234, 55, 34, 1, 75)] as [String : Any]

print("Element 1 = \(String(describing: newDict["name"]!))")
print("Element 2 = \(String(describing: newDict["Score"]!))")


let testArray = ["23", 23, 23.0] as [Any]
print("\n")




//Homework for Swift maraphon
print("Homework fow Alex Skutarenko\n")
//Task 01
/*
 Создайте пару функций с короткими именами, которые возвращают строку с классным символом или символами.
 Например heart() возвращает сердце и т.п.
 Вызовите все эти функции внутри принта для вывода строки этих символов путем конкатенации.
 */



//1

func stringEmoji() -> String {
    
    
    return "\u{1F602} \u{1F49C} \u{1F4AA} \u{1F525} \u{1F64F}"
}

print(stringEmoji())


//2

let myFavoriteString = "\u{1F602} \u{1F49C} \u{1F4AA} \u{1F525} \u{1F64F}"

func strEmoji(str: String) -> String {
    
    return str
}

print("My favorite emoji from function: \(strEmoji(str: myFavoriteString))")






print("\u{1F602}")
print("\u{1F49C}")
print("\u{1F4AA}")
print("\u{1F525}")
print("\u{1F64F}")

//3

func faceSunglasses() -> String {
    let face = "\u{1F60E}"
    return face
}

func fire() -> String {
    return "\u{1F525}"
}

func hands() -> String {
    let hands = "\u{1F91D}"
    return hands
}

func skull() -> String {
    let skull = "\u{2620}"
    return skull
}

func snow() -> String {
    return "\u{2744}"
}


print(faceSunglasses() + fire() + hands() + skull() + snow())

let skull1 = skull()
print(skull())



//Task 2
/*
 Опять шахматные клетки. Реализовать функцию, которая принимает букву и символ и возвращает строку “белая” или “черная”. Строку потом распечатайте в консоль
 */
print("\nTask 2")


//Мои варианты
//1
func chessCheck(num: Int?, letter: String?) -> String? {
    let dictLetter = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
    
    guard letter != nil && num != nil else {
        return "Empty letter value"
    }
    
    let upperLetter = letter!.uppercased()
    
    guard dictLetter[upperLetter] != nil && num! < 9 && num! > 0 else {
        return "Invalid value"
    }
    
    if num! % 2 == dictLetter[upperLetter]! % 2 {
        return "Black cell"
    } else {
        return "White cell"
    }
    
    
    //return ""
}


chessCheck(num: 2, letter: "B")
print("Black or White: \(chessCheck(num: 4, letter: "F") ?? "nil")")


//2
func checkColor(letter: String, number: Int) -> String {
    let dictLetter = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
    
    guard dictLetter[letter] != nil && number < 9 else {
        return "Invalid value"
    }
    
    switch (number, dictLetter[letter]!) {
        case (let n, _) where n == 0:
            //return "Null valid value"
            fallthrough
        case (let n, _) where n < 0:
            return "Negative and null value's not use"
        case let(n, d) where n % 2 == d % 2:
            return "Black color"
        default:
            return "White color"
        
    }

}

print(checkColor(letter: "C", number: 5))



/*
let dictLetter = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]



func myNewTest() -> () {
    print("Hello World!")
}

var linkFunc = myNewTest()
linkFunc
*/


//3

func chessInfo(letter: String, symbol: String) -> String {
    let number = Int(symbol)
    let dictLetter = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
    let upperLetter = letter.uppercased()
    
    guard number != nil && dictLetter[upperLetter] != nil else {
        return "Writed invalid value!"
    }
    
    switch (number!, dictLetter[upperLetter]!) {
        case (let n, _) where n == 0:
            fallthrough
        case (let n, _) where n > 8:
            return "Number or letter have invalid value"
        case let(n, l) where n % 2 == l % 2:
            return "Cell is Black color"
        default:
            return "Cell is White color"
    }
}

let checkCell = chessInfo(letter: "z", symbol: "3")

print("My 3 check in cell: \(checkCell)")




//Вариант Алексея Скутаренко + Мой

func chessAlex(cell: Int?, letter: String?) -> String? {
    let alphabet = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
    
    guard cell != nil && letter != nil else {
        return "Invalid value"
    }
    
    guard cell! > 0 && cell! < 9 && alphabet[letter!] != nil else {
        return "Cell or letter have invalid value"
    }
    
    return (cell! % 2 == alphabet[letter!]! % 2) ? "Black COLOR!" : "White Color"
}

let alexMethod = chessAlex(cell: 2, letter: "H")

print("Alex method result: \(alexMethod)")




//Task 03
/*
 Создайте функцию, которая принимает массив, а возвращает массив в обратном порядке.
 Можете создать еще одну, которая принимает последовательность и возвращает массив в обратном порядке.
 Чтобы не дублировать код, сделайте так, чтобы функция с последовательностью вызывала первую.
 */
print("\nTask 03")

//1.1
let arrayNumbers = [27, 93, 01, 2021, 007, 229, 34, 49]

func reverseArray(array: [Any]) -> [Any] {
    return array.reversed()
}

let resultArr = reverseArray(array: arrayNumbers)
print("Array \(resultArr)")


//1.2

func revArray(array: [Any]) -> [Any] {
    var inoutArray = [Any]()
    
    for i in array {
        inoutArray.insert(i, at: 0)
    }
    
    return inoutArray
}

let arrayReversed = revArray(array: arrayNumbers)
print("Reversed array: \(arrayReversed)")

var arrayNames = ["Alex", "John", "Bob", "Jack"]
let nameArray = revArray(array: arrayNames)
print("Array name's: \(nameArray)")



//1.3
//Данная функция вызывает другую функцию
func sequenceArray(seq: Any...) -> [Any] {
    var newArray = [Any]()
    
    for i in seq {
        newArray.append(i)
    }
    
    return reverseArray(array: newArray)
}

let number_1 = 998973421139
let number_2 = 998706132401
let number_3 = 1109542
let seqArray = sequenceArray(seq: number_1, number_2, number_3)
print("Sequence array: \(seqArray)")


let name_1 = "Sam"
let name_2 = "Peter"
let name_3 = "Dereck"
let name_4 = "Fred"
let namesArray = sequenceArray(seq: name_1, name_2, name_3, name_4)
print("Names array reverse: \(namesArray)")


//Task 04
/*
 Разберитесь с inout самостоятельно и выполните задание номер 3 так, чтобы функция не возвращала перевернутый массив, но меняла элементы в существующем.
 Что будет если убрать inout?
 */

//1
var arrayInt = [3, 4, 5, 5, 6, 2, 0, 6]

func reverseArray2(array: [Int]) -> [Int] {
    return array.reversed()
}


func inoutArray(iArray: inout [Int]) {
    iArray = reverseArray2(array: iArray)
}

inoutArray(iArray: &arrayInt)

print("Array Int \(arrayInt)")


//2

var myTestArray = [1, 2, 3, 4, 5, 6, 7, 8, 9]

func reverse(array: inout [Int]) {
    //array.removeAll()
    //array = reverseArray2(array: array)
    array.reverse()
}

reverse(array: &myTestArray)

print("My second test: \(myTestArray)")


//3

var otherNumbers = [10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]

func manualReverse(anyArray: inout [Int]) {
    for i in anyArray {
        anyArray.insert(i, at: 0)
    }
}

manualReverse(anyArray: &otherNumbers)

print("Manual reverse inout function: \(otherNumbers)")
type(of: otherNumbers)






//Массив с любыми типами
let allAny: [Any] = [23, 23.0, "All"]

type(of: allAny)



//Task 05
print("\nTask 05")
/*
  Создайте функцию, которая принимает строку, убирает из нее все знаки препинания, делает все гласные большими буквами,
 согласные маленькими, а цифры меняет на соответствующие слова (9 -> nine и тд)
 */


var otherText = """
Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. RichardMcClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from "de Finibus Bonorum et Malorum" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.
"""

func clearText(text: String) -> String {
    
   // text.lowercased()
    var newText = ""
    for symbol in text.lowercased() {
        
        switch symbol {
            case "a", "e", "u", "o", "i":
                newText.append(symbol.uppercased())
            case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
                newText.append(symbol)
            case "0":
                newText.append("zero")
            case "1":
                newText.append("one")
            case "2":
                newText.append("two")
            case "3":
                newText.append("three")
            case "4":
                newText.append("four")
            case "5":
                newText.append("five")
            case "6":
                newText.append("six")
            case "7":
                newText.append("seven")
            case "8":
                newText.append("eight")
            case "9":
                newText.append("nine")
            default:
                newText.append(" ")
        }
    }
    
    return newText
}


let testTest = clearText(text: otherText)
print(testTest)


// b c d f g h j k l m n p q r s t v w x y z


//2

func editText(txt: inout String) {
    
    var str = " "
    let numDict = ["0": "zero", "1": "one", "2": "two", "3": "three", "4": "four", "5": "five", "6": "six", "7": "seven", "8": "eight", "9": "nine"]
    
    for symbol in txt.lowercased() {
        
        switch symbol {
            case "a", "e", "u", "o", "i":
                str.append(symbol.uppercased())
            case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
                str.append(symbol)
            case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9":
                str.append(numDict[String(symbol)]!)
            default:
                str.append(" ")
        }
    }
    
    txt = str
}

editText(txt: &otherText)

print("\nSecond TEST!")
print(otherText)



var jk = "wae"

jk.insert("w", at: jk.index(before: jk.endIndex))



