//Lesson_12
//Enumerates

enum Direction: String {
    case Left = "Left!"
    case Right = "Right!"
}

enum Action {
    case Walk(meters: Int)//Ассоциативные значения
    case Run(meters: Int, speed: Double)
    case Stop
    case Turn(direction: Direction)
}


var action = Action.Run(meters: 20, speed: 15.0)
//action = .Stop
//action = .Walk(meters: 500)
//action = .Turn(direction: "Left") <-- Wrong!

//action = .Turn(direction: .Left)
var direction = Direction(rawValue: "Right!")!
action = .Turn(direction: direction)

switch action {
    case .Stop:
        print("Stop")
    //case .Walk(let meters):
       // print("Walk \(meters) meters")
    case .Walk(let meters) where meters < 100:
        print("Short walk")
    case .Walk(_):
        print("Long walk")
    case .Run(let m, let s):
        print("Run \(m) meters with speed \(s)")
    case .Turn(let dir) where dir == .Left:
        print("Turn left")
    case .Turn(let dir) where dir == .Right:
        print("Turn right")
    default:
        break
}

print(Direction.Left.rawValue)



enum CompassPoint {
    case north
    case south
    case east
    case west
}


enum Planet {
    case mercury, venus, earth, mars,
        jupiter, saturn, uranus, neprune
}

var directiontoHead = CompassPoint.north
directiontoHead = .south

var namePlanet: Planet = .jupiter
namePlanet = .mars

//Словари и списки
enum DifferentEnum {
    case name(name: String)
    case age(age: Int)
    case weight(weight: Double)
}

let dictionaryForEnum: [String: DifferentEnum] = ["Name": .name(name: "Alexander"), "Age": .age(age: 27), "Weight": .weight(weight: 78.5)]


for i in dictionaryForEnum.keys {
    print("Key \(i) and value \(dictionaryForEnum[i]!)")
}


//Использование перечислений с инструкцией switch
//С полным перечислением без кейса default
directiontoHead = .south
switch directiontoHead {
    case .north:
        print("Lots of planets have a north")
    case .south:
        print("Watch out for  penguins")
    case .east:
        print("Where the sun rises")
    case .west:
        print("Where the skies are blue")
}


//не полное перечисление с кейсом default

let somePlanet = Planet.earth

switch somePlanet {
    case .earth:
        print("Mostly harmless")
    default:
        print("Not a safe place for humans")
}



//Итерация по кейсам перечисления

enum Beverage: CaseIterable {
    case coffe, tea, juice
}

let numberOfChoices = Beverage.allCases.count //Узнаём количество кейсов
print("\(numberOfChoices) beverages available")

for bevereage in Beverage.allCases { // Выводим через цикл for все элементы списка
    print(bevereage)
}


//Ассоциативные значения

enum Barcode {
    case upc(Int, Int, Int, Int)
    case qrCode(String)
}


var productBarcode = Barcode.upc(8, 85909, 51226, 3)
productBarcode = .qrCode("ABCDEFGHIJKLMNOP")

//Аналоги value binding

switch productBarcode {
    case .upc(let numberSystem, let manufacturer, let product, let check):
        print("UPC: \(numberSystem), \(manufacturer), \(product), \(check)")
    case .qrCode(let productCode):
        print("QR code: \(productCode)")
}


switch productBarcode {
    case let .upc(numberSystem, manufacturer, product, check):
        print("UPC: \(numberSystem), \(manufacturer), \(product), \(check)")
    case let .qrCode(productCode):
        print("QR code: \(productCode)")
}



//Исходные значения или сырые значения

enum ASCIIControlCharacter: Character { //При помощи них задаются дефолтные значения
    case tab = "\u{2726}"
    case lineFed = "\n"
    case carriageReturn = "\r"
}


var testOpt = ASCIIControlCharacter.tab
print("\(testOpt.rawValue)")


//Неявно установленные исходные значения

enum Planets: Int {
    case mercury = 1 //Если первое значение проиницализировано, то следующее будет равно +1 автоматически
    case venus
    case earth
    case mars
    case jupiter
    case saturn
    case uranus
    case neptune
}

print(Planets.saturn.rawValue)

enum CompassPoints: String { //Если сырое значение типа стринг не проинициализировано, то значение будет установлено согласно имени кейса
    case north
    case south
    case east
    case west
}

print(CompassPoints.east.rawValue)


//Для доступа к сырому значению используется оператор rawValue
let west = CompassPoints.west.rawValue


//Инициализация через исходное значение

//Вызов кейса через исходное значение
let possiblePlanet = Planets(rawValue: 7) //Если будет указано несуществующее исходное значение, то вернётся nil


let positionToFind = 11
if let somePlanet = Planets(rawValue: positionToFind) {
    switch somePlanet {
        case .earth:
            print("Mostly harmless")
        default:
            print("Not a safe place for humans")
    }
} else {
    print("There isn't a planet at position \(positionToFind)")
}


//Рекурсивные перечисления


enum ArithmeticExpression {
    case number(Int)
    indirect case addition(ArithmeticExpression, ArithmeticExpression)
    indirect case multiplication(ArithmeticExpression, ArithmeticExpression)
}

indirect enum ArithmeticExpression1 {
    case number(Int)
    case addition(ArithmeticExpression1, ArithmeticExpression1)
    case multiplication(ArithmeticExpression1, ArithmeticExpression1)
}

let five = ArithmeticExpression1.number(5)
let four = ArithmeticExpression1.number(4)
let sum = ArithmeticExpression1.addition(five, four)
let product = ArithmeticExpression1.multiplication(sum, ArithmeticExpression1.number(2))


func evaluate(_ expression: ArithmeticExpression1) -> Int {
    switch expression {
        case let .number(value):
            return value
        case let .addition(left, right):
            return evaluate(left) + evaluate(right)
        case let .multiplication(left, right):
            return evaluate(left) * evaluate(right)
    }
}

print(evaluate(sum))




enum Properties {
    case name(yourName: String)
    case weight(yourWeight: Double)
    case height(yourHeigt: Double)
    case age(yAge: Int)
    case carNumber(number: String)
}


let name = Properties.name(yourName: "Bob")
let weight = Properties.weight(yourWeight: 78.3)
let height = Properties.height(yourHeigt: 168.0)
let age = Properties.age(yAge: 22)
let carNumber = Properties.carNumber(number: "1AA222OF")



switch name {
    case let .name(n):
        print(n)
    case let .age(yAge):
        print(yAge)
    default:
        break
}





enum rawEnum: Int {
    case num1 = 234
    case num2 = 33
    case num3 = 943
}

let fsa = rawEnum.num1


let test = rawEnum(rawValue: 33)

switch test {
    case .num1:
        print("\(rawEnum(rawValue: 33)!)")
    case .num2:
        print("\(rawEnum(rawValue: 234)!)")
    case .num3:
        print("\(rawEnum(rawValue: 943)!)")
    default:
        break
}





enum ChessMembers {
    case pawn(ColorChess)
    case horse
    case elephant
    case rook
    case queen
    case king
    
    enum ColorChess: Character {
        case black = "\u{2B1B}"
        case white = "\u{2B1C}"
    }
}


let pawn = ChessMembers.ColorChess.black

print(pawn)

print("\u{2B1C}")




enum ServiceMan {
    case name(name: String)
    case age(value: Int)
    case sex(s: String)
    case experience(exp: Int)
    case country(contr: Countrys)
    
    enum Countrys: String {
        case usa = "USA"
        case japan = "Japan"
        case france = "France"
    }
}


let man: ServiceMan = .name(name: "Alex")
var ageMan: ServiceMan = .age(value: 22)
let sexMan: ServiceMan = .sex(s: "Men")
let expServise: ServiceMan = .experience(exp: 3)
let contry: ServiceMan = .country(contr: .japan)


switch contry {
    case .country(let usa) where usa == .usa:
        print("Your country USA")
    case .name(name: "Alex"):
        print("Your name Alex")
    case .age(value: 23):
        print("Your age confirm!")
    case  .country(let cont) where cont == .japan:
        print("Your contry Japan")
    default:
        print("Not found information")
}



enum test1 {
enum test {
    case black
    case white
}
    case king(ts: test)

}




enum Actions {
    case Walk(meters: Int)
    case Run(meters: Int, speed: Double)
    case Stop
    case Turn(direction: Directions)
    
    enum Directions: String {
        case Left = "Left!"
        case Right = "Right!"
    }
}

print(Actions.Directions.Left.rawValue)


var act = Actions.Directions(rawValue: "Right!")!



var actions = Actions.Run(meters: 20, speed: 15)
actions = .Stop
//actions = .Walk(meters: 10)
actions = .Turn(direction: act)

switch actions {
    case .Stop:
        print("Stop")
//    case let .Run(meters, speed):
//        print("Run meters \(meters) speed \(speed)")
    case .Walk(let meters) where meters < 100:
        print("Short walk")
    case .Walk(let meters):
        print("Long walk \(meters)")
    case let .Run(meters, speed):
        print("Run \(meters) meters with speed \(speed)")
    case .Turn(let dir) where dir == .Left:
        print("Turn Left")
    case .Turn(let dir) where dir == .Right:
        print("Turn Right")
    default:
        break
}





//Книга Василия Усова

//Create enum
enum CurrencyUnit {
    case rouble
    case euro
    case sum, tenge
}

//Value enum type
var roubleCurrency: CurrencyUnit = .rouble
var otherCurrency = CurrencyUnit.euro
var sumCurrency = CurrencyUnit.sum
var tengeCurrency = CurrencyUnit.tenge
otherCurrency = .rouble

//Enum in enum
enum AdvencedCurrencyUnit {
    case rouble(countries: [String], shortName: String)
    case euro(countries: [String], shortName: String)
    case dollar(nation: DollarCountries, shortName: String)
    
    enum DollarCountries {
        case usa
        case canada
        case australia
    }
}

var euroCurrency: AdvencedCurrencyUnit = .euro(countries: ["German", "France"], shortName: "EUR")
var dollarCurrency: AdvencedCurrencyUnit = .dollar(nation: .usa, shortName: "USD")

var australia: AdvencedCurrencyUnit.DollarCountries = .australia



//Switch with enum
//Value binding for enum

switch dollarCurrency {
    case .rouble:
        print("RUB")
    case let .euro(countries, shortName):
        print("Euro. Countries: \(countries). Short name: \(shortName)")
    case .dollar(let nation, let shortName):
        print("Dollar \(nation). Short name: \(shortName)")

}


//Raw value

enum Smile: String {
    case joy = ":)"
    case laugh = ":D"
    case sorrow = ":("
    case surprise = "o_O"
}

//Auto - default value

enum NewPlanets: Int {
    case mercury = 1
    case venus
    case earth, mars
    case jupiter
    case saturn
    case uranus
    case neptune
    case pluton = 999
    
}


//Access raw value
let earth = NewPlanets.earth.rawValue
print("Earth have value \(earth)")
print("Pluton have value \(NewPlanets.pluton.rawValue)")

var iAmHappy = Smile.joy
iAmHappy.rawValue


let smile = Smile(rawValue: "\(iAmHappy.rawValue)")
print("Smile variable have value \(smile ?? Smile.laugh))")
let smile_2 = Smile(rawValue: ":(")
print("Smile_2 have value \(smile_2!)")


//Inicialization
var myPlanet = Planets.init(rawValue: 3)
var anotherPlanet = Planets.init(rawValue: 11)


//Property's in enum

enum Smiles: String {
    case joy = ":)"
    case laugh = ":D"
    case sorrow = ":("
    case surprise = "o_O"
    
    //let description: String {return self.rawValue}
    var description: String {return self.rawValue} //Данное свойство всегда должно быть var
}

let mySmile: Smiles = .sorrow
mySmile.description

let myJoy: Smiles = .joy
myJoy.description




//Methods in enum

enum SmilesForMethods: String {
    case joy = ":)"
    case laugh = ":D"
    case sorrow = ":("
    case surprise = "o_O"
    
    var description: String {return self.rawValue}
    
    //Метод внутри списка
    func about() {
        print("Перечисление содержит список смайликов")
    }
    
    func test(iVar: SmilesForMethods.RawValue) -> String {
        return "\(iVar) just simple"
    }
}

var otherSmile = SmilesForMethods.joy
otherSmile.about()

otherSmile.test(iVar: SmilesForMethods.surprise.rawValue)





//Self

enum SmilesForSelf: String {
    case joy = ":)"
    case laugh = ":D"
    case sorrow = ":("
    case surprise = "o_O"
    
    //let description: String {return self.rawValue}
    var description: String {return self.rawValue} //Данное свойство всегда должно быть var
    
    func about() {
        print("Перечисление содержит список смайликов")
    }
    
    func descriptionValue() -> SmilesForSelf {
        return self
    }
    
    func descriptionRawValue() -> String {
        return self.rawValue
    }
    
}


var smileOther = SmilesForSelf.joy
smileOther.descriptionValue()
smileOther.descriptionRawValue()



//Рекурсивные перечисления

enum ExpressionArithmetic {
    case addition(Int, Int)
    case subtraction(Int, Int)
    
    func evaluate() -> Int {
        switch self {
            case .addition(let left, let right):
                return left + right
            case .subtraction(let left, let right):
                return left - right
        }
    }
    
}

var expr = ExpressionArithmetic.addition(10, 14)
expr.evaluate()



enum ArithmeticExpression_3 {
    case number(Int)
    indirect case addition(ArithmeticExpression_3, ArithmeticExpression_3)
    indirect case subtraction(ArithmeticExpression_3, ArithmeticExpression_3)
    
    //Метод для операции
    func evaluate(expression: ArithmeticExpression_3? = nil) -> Int {
        switch expression ?? self {
            case let .number(value):
                return value
            case let .addition(valueLeft, valueRight):
                return self.evaluate(expression: valueLeft) + self.evaluate(expression: valueRight)
            case .subtraction(let valueLeft, let valueRight):
                return self.evaluate(expression: valueLeft) - self.evaluate(expression: valueRight)
            
        }
    }
    
}

var hardexpr = ArithmeticExpression_3.addition(.number(20), .subtraction(.number(10), .number(34)))
hardexpr.evaluate()
hardexpr.evaluate(expression: hardexpr)




for _ in 1...8 {
    let  plus = "+"
    print(plus)
    for _ in 1...8 {
        let minus = "-"
        print(minus + plus)
    }
}






enum Student {
    
    enum NameAndSurname {
        case name(name: String)
        case surName(srName: String)
    }
    
    enum OtherInfo {
        case age(Int)
        case dateBorn(Int)
    }
    
    enum Action: String {
        case walk = "Walk to garden"
        case stop = "Stop right now"
        case run = "Run to maraphon"
    }
    
    case person(name: String, surname: NameAndSurname, age: OtherInfo, dateBorn: OtherInfo, action: Action)
    
}


let newPerson: Student = .person(name: "Alex", surname: .surName(srName: "Kim"), age: .age(22), dateBorn: .dateBorn(1992), action: .run)


switch newPerson {
    case let .person(name, surname, age, dateBorn, action):
        print("Student \(name) \(surname). Age \(age). Date birth \(dateBorn). Action \(action.rawValue)")
}
