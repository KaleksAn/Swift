//Homework for Swiftt maraphon

//Task 01
/*
 Написать функцию, которая ничего не возвращает и принимает только один клоужер, который ничего не принимает и ничего не возвращает.
 Функция должна просто посчитать от 1 до 10 в цикле и после этого вызвать клоужер.
 Добавьте println в каждый виток цикла и в клоужер и проследите за очередностью выполнения команд
 */

func emptyFunction(closur: () -> ()) {
    var result = 0
    for _ in 1...10 {
        result += 1
        print("Result in loop equal: \(result)")
       // closur()
    }
    closur()
}

emptyFunction {
    print("This is print from closure!")
}




//Task 02
/*
 Используя метод массивов sorted, отсортируйте массив интов по возрастанию и убыванию.
 Пример показан в методичке.
 */

var arrayInt = [10, 2, 5, 100, 50, 20, 1, 75, 1000, 0, -1]

//Возвращает отсортированный массив
arrayInt.sort(by:){$0 < $1}
print(arrayInt)
arrayInt.sort(by: {(num1, num2) -> Bool in return num1 > num2})
print(arrayInt)

//Возвращает новый отсортированный массив
let sorted = arrayInt.sorted(by: {$0 < $1})
print(sorted)



//Task 03
/*
 Напишите функцию, которая принимает массив интов и клоужер и возвращает инт.
 Клоужер должен принимать 2 инта (один опшинал) и возвращать да или нет.
 В самой функции создайте опшинал переменную.
 Вы должны пройтись в цикле по массиву интов и сравнивать элементы с переменной используя клоужер.
 Если клоужер возвращает да, то вы записываете значение массива в переменную. В конце функции возвращайте переменную.
 Используя этот метод и этот клоужер найдите максимальный и минимальный элементы массива.
 */


let newArray = [10, 900000, 2, 5, 100, 45000, 50, 20, 1, 75, 10000, -1, -10, 250000000, -8000]

func arrayAndClosure(array: [Int], closure:(Int, Int?) -> Bool) -> Int {
    var varOptional: Int?
    for index in 0..<array.count {
            if closure(array[index], varOptional) {
                varOptional = array[index]
            }
    }
    return varOptional ?? 0
}


let maximumValue = arrayAndClosure(array: newArray){$1 == nil || $0 < $1!}



let minimumValue = arrayAndClosure(array: newArray){(num1, optNum)  in
    if optNum == nil {
        return true
    } else if let num = optNum {
            return num1 < num
    }
    return false
}

print("Minimum value: \(minimumValue)")
print("Maximum value: \(maximumValue)")




//Task 04

/*
 Создайте произвольную строку. Преобразуйте ее в массив букв.
 Используя метод массивов sorted отсортируйте строку так, чтобы вначале шли гласные в алфавитном порядке, потом согласные, потом цифры, а потом символы
 */

let str = "Message:(27.03.2021) Hello Swift Developers!"

func sortStr(iString: String) -> [Character] {
   var arrayCharacters = [Character]()
    for letter in iString {
        arrayCharacters.append(letter)
    }
    
    return arrayCharacters
}



var arrChar = sortStr(iString: str)


func sortCharacter(char: Character) -> Int {
    switch char.lowercased() {
        case "a", "e", "i", "o", "u":
            return 0
        case "b"..."z":
            return 1
        case "0"..."9":
            return 2
        default:
            return 3
    }

}


let resArr = arrChar.sorted(by:){switch(sortCharacter(char: $0), sortCharacter(char: $1)) {
    case let(x, y) where x < y:
        return true
    case let(x, y) where x > y:
        return false
    default:
        return $0.lowercased() <= $1.lowercased()
}}


print(resArr)



//Task 05
/*
 Проделайте задание №3 но для нахождения минимальной и максимальной буквы из массива букв (соответственно скалярному значению)
 */

let letterArray = ["Z", "B", "D", "W", "O"]

func arraySortLetter(array: [String], closure: (Int, Int?) -> Bool ) -> String {
    var optString: String?
    var optVar: Int?
    
    for i in array {
        let scalarValue = Int(UnicodeScalar(String(i))!.value)
        
        if closure(scalarValue, optVar) {
            optVar = scalarValue
            optString = i
        }
    }
    
    return optString ?? "nil"
}





/*
 Создать метод который запрашивает имена друзей, после этого имена положить в массив.
 Массив отсортировать по количеству букв в имени.
 */


func namesArray(names: String...) -> [String] {
    var namesArray = [String]()
    
    for name in names {
        namesArray.append(name)
    }
    
    return namesArray
}




var names = namesArray(names: "Alex", "Dmitruy Olegovich", "Dima", "Bob", "Alina", "Kristina,", "Alexander" )

names[2].count

names.sorted(by:){(name1, name2) -> Bool in
    switch (name1.count, name2.count) {
        case let(x, y) where x < y:
            return true
        case let(x, y) where x > y:
            return false
        default:
            return false
    }
}

names.sorted(by:){ switch ($0.count, $1.count) {
    case let(x, y) where x <= y:
        return true
    case let(x, y) where x >= y:
        return false
    default:
        return false
}}


/*
 Написать функцию которая будет принимать ключи, выводить ключи и значения словаря (Dictionary).
 Тип ключа и значения выбирайте сами.
 */


func keysForDict(key: Int...) -> String {
    
    let myDictionary = [119: "Emergency service", 102: "Police", 101: "Fire departament"]
    var str = ""
    for k in key {
       
        str.append(" Key: \(k) value: \(myDictionary[k] ?? "nil value"), ")
    }
    
    return str
}

let list = keysForDict(key: 101, 102, 119, 103, 105, 106)

print(list)


/*
 Написать функцию, которая принимает пустые массивы(один строковый, второй - числовой) и проверяет их: если пустой - то добавить значения и вывести в консоль.
 */


func emptyArrays(arrayStr str: inout [String], arrayInt int: inout [Int]) {
    switch str {
        case let s where s.isEmpty:
            str.append("Hello world!")
            str.append("Hola")
            print("Array str have values: \(str)")
        default:
            print("Array is not empty")
    }
    
    switch int {
        case let i where i.isEmpty:
            int.append(23)
            int.append(25)
            print("Array int have value: \(int)")
        default:
            print("Array int is not empty")
    }
}



var numbers = [2, 3, 4, 5]
var strings = ["2", "we", "wwe"]

let others: () = emptyArrays(arrayStr: &strings, arrayInt: &numbers)
