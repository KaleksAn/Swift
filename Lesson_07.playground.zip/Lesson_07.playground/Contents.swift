

//Arrays

//Create empty array
var someInts = [Int]() // empty array
var someStrings = Array<String>()
var someFloat: [Float] = []


print("someInts is of type [Int] with \(someInts.count) items")


someInts.append(3)
someInts = []

var threeDoubles = Array(repeating: 0.0, count: 5)
var fourValue = Array(repeating: 4, count: 5)
let goodPhrase = Array(repeating: "WIN!", count: 3)

let rangeArray = Array(0...10)
print("Range array: \(rangeArray[6]), \(goodPhrase)")

if rangeArray.contains(3) {
    print("True!")
}

rangeArray.count



someInts = fourValue
someInts = []
someInts += fourValue


var anotherThreeDoubles = Array(repeating: 2.5, count: 3)
var sixDoubles = threeDoubles + anotherThreeDoubles
sixDoubles

someInts = []




var shopingList = ["Eggs", "Milk"]
print("The shoping list contains \(shopingList.count) items")

if shopingList.isEmpty {
    print("Shoping list is empty")
} else {
    print("Shoping list not empty")
}

//Add new element on array
shopingList.append("Juce")

print("New shoping list \(shopingList)")


let meat = "Meat"
let mashrooms = "Mashrooms"
let apple = "Apple"
let raspberry = "Raspberry"
let chocolate = "Chocolate"

shopingList += [meat]
shopingList += ["Fish"]
shopingList += []
shopingList += [mashrooms]
shopingList += [chocolate, apple, raspberry]


print("Shoping list add new note \(shopingList)")

shopingList.removeLast()
print("Shoping list add new note \(shopingList)")

shopingList.remove(at: 4)
shopingList.append("Fish")

shopingList.removeFirst()
print("Shoping list add new note \(shopingList)")

shopingList.removeLast(2)
print("Shoping list add new note \(shopingList)")

var firstItem = shopingList[0]
var secondItem = shopingList[1]
var threeItem = shopingList[2]

//изменение значения элемента в массиве согласно индексу
shopingList[0] = "Potato"
print("Shoping list add new note \(shopingList)")

shopingList[1...4] = ["Bananas", "Date", "Grape", "Coca-Cola"]

print("Shoping list add new note \(shopingList)")



//Вставка по индексу
shopingList.insert("Cacke", at: 0)
print("Shoping list add new note \(shopingList)")


//Удаление по индексу
shopingList.remove(at: 5)
print("Shoping list add new note \(shopingList)")

//Удаление объекта и его сохранение
var deletedValue = shopingList.remove(at: 2)
print("Deleted object: \(deletedValue)")
print("Shoping list add new note \(shopingList)")
print("All objects in array: \(shopingList.count)")
shopingList.remove(at: 0)
print("Shoping list add new note \(shopingList)")

shopingList += shopingList
print("Shoping list add new note \(shopingList)")
shopingList.removeLast(3)
print("Shoping list add new note \(shopingList)")


//Итерация по массиву
for i in shopingList {
    print(i)
}


// метод enumerated возвращает тюпл значения и индекса
var x = 0
for (index, value) in shopingList.enumerated() {
    print("Index \(index) value \(value)")
    if x < shopingList.count {
        print("Elements:\(shopingList[x])")
        x += 1
    }
}



// альтернатива var i =0; i < shopingList.count; ++i
for i in 0..<shopingList.count {
    print("Element:\(shopingList[i]) and index: \(i)")
}
 

//Добавление массива в массив через метод
shopingList.append(contentsOf: ["Pizza", "Chiken", "Hot-Dog"])
print("Shoping list: \(shopingList)")

//Обычным сложением
shopingList += ["Lays", "RedBull", "Mars"]
print("Shoping list: \(shopingList)")

shopingList[3...5] = ["Fish"]
shopingList


//Копирование массива

let newArr = ["Hello", "World!"]
var copyArr = newArr

copyArr[1] = "Man!"

print("Array newArr: \(newArr)")
print("Array copyArr: \(copyArr)")


//Создание пустого массива

var emptyArr = [Int]()
var anotherEmptyArr = Array<String>()
var thirdArr: [String] = []

anotherEmptyArr.isEmpty

let a1 = 1
let a2 = 2
let a3 = 3

var arrayForEqual = [a1, a2, a3]
var arrayNumbers = [1, 2, 3]

arrayForEqual == arrayNumbers
arrayNumbers == [a1, a2, a3]

// Слияние

let char1 = ["A", "B", "C"]
var char2 = ["D", "E", "F"]
var char3 = ["G", "H", "I"]

var charArray = char1 + char2
print("Char1 + char2 equal: charArray \(charArray)")

charArray += char3
print("Char3 + charArray equal: \(charArray)")


//Многомерный массив
var arrayOfArrays = [[char1], [char2, 234], [char3]]
print("Call element array \(arrayOfArrays[1])")
print("Call elemen array of array \(arrayOfArrays[1][0])")
let test = arrayOfArrays[1]

let newArraysOnArray = [[1, 2, 3], [4, 5, 6]]
newArraysOnArray[1][2]



//Property

var numArray = [1, 2, 3, 4, 5, 6, 7, 8]
numArray.count

let sliceArray = numArray[numArray.count - 5...numArray.count-2]

sliceArray

let subArray = numArray.suffix(4)

let minValue = numArray.min()
let maxValue = numArray.max()


//Сортировка массива

var unsortedArray = [2, 34, 0, 55, 103, 1, 325]
let sortedArray = unsortedArray.sorted()


let testOptional = unsortedArray[2]
print("Element from unsortedArray: \(type(of: testOptional))")

unsortedArray
sortedArray

unsortedArray.sort()
unsortedArray

//Random value from array

let randomValue = unsortedArray.randomElement()
print("Random value from array: \(randomValue!)")


var arraySlice = Array(1...15)
print("Array numbers: \(arraySlice)")

let newTypeArray = arraySlice[4...6]
print("New type array: \(type(of: newTypeArray))")

newTypeArray[5]

arraySlice.dropLast()

//let abrabra = arraySlice.dropFirst()
let abrabra = Array(arraySlice.dropFirst()) // convert type ArraySlice to Array
type(of: abrabra)






//Homework

//Task 1
//Wallet

var wallettCash = [1, 100, 20, 20, 50, 5, 100,]
var sumTotal = 0

for i in 0..<wallettCash.count {
    sumTotal += wallettCash[i]
    print("Value: \(wallettCash[i])")
    
    if sumTotal <= 300 && sumTotal > 280 {
        wallettCash.append(100)
        sumTotal += 100
        print("You have bonus! Total balance: \(sumTotal)")
    }
}

print("Total cash in wallet:\(sumTotal)")





//Task 2
//Months

let daysInMonths = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
let nameMonths = ["January", "February", "March", "April", "May", "June", "Jule", "August", "September", "October", "November", "December"]

//1
for i in 0..<daysInMonths.count {
    print("Days on month: \(daysInMonths[i])")
}


for (index, month) in nameMonths.enumerated() {
    print("Month \(month) have index \(index)")
}


for i in daysInMonths {
    print("Days on month = \(i)")
}

//2

for i in 0..<daysInMonths.count {
    print("Months: \(nameMonths[i]) \(daysInMonths[i])")
}


//Название месяцев в цикле

for i in nameMonths {
    print("Name month: \(i)")
}


//3 Мой хреновый вариант!
let monthsAndDays = [(nameMonths[0], daysInMonths[0]), (nameMonths[1], daysInMonths[1]), (nameMonths[2], daysInMonths[2]), (nameMonths[3], daysInMonths[3]), (nameMonths[4], daysInMonths[4]), (nameMonths[5], daysInMonths[5]), (nameMonths[6], daysInMonths[6]), (nameMonths[7], daysInMonths[7]), (nameMonths[8], daysInMonths[8]), (nameMonths[9], daysInMonths[9]), (nameMonths[10], daysInMonths[10]), (nameMonths[11], daysInMonths[11])]

for i in 0..<monthsAndDays.count {
    print("Months: \(monthsAndDays[i])")
}


let monthsAndDays_2 = [("January", 31), ("February", 28), ("March", 31), ("April", 30), ("May", 31), ("June", 30), ("Jule", 31), ("August", 31), ("September", 30), ("October", 30), ("November", 31), ("December", 31)]


for i in 0..<daysInMonths.count {
    print("Months and days: \(monthsAndDays_2[i])")
}


//Вариант Алексея Скутаренко
//-----------------------------------------------------------------------------------------------
var emptyArrMonth = [(month: String, days: Int)]()

for i in 0..<daysInMonths.count {
    emptyArrMonth.append((nameMonths[i], daysInMonths[i]))
    
    print("Month \(emptyArrMonth[i].month) have \(emptyArrMonth[i].days) days")
    
}

//----------------------------------------------------------------------------------------------

for (index, month) in nameMonths.enumerated() {
    print("Index \(index) month \(month)")
}



//4
//Reverse days array

for i in stride(from: nameMonths.count-1, to: 0, by: -1) {
    print("List days on months: \(nameMonths[i]) and days \(daysInMonths[i]) ")
}




//Task for days to birth

//Вариант Алексея
let dob = (dayBirth: 9, monthBirth: nameMonths[7])//Вариант Алексея
var dToBirth = 0

for i in 0..<nameMonths.count {
    if dob.monthBirth == nameMonths[i] {
        dToBirth += dob.dayBirth
        print("\(nameMonths[i]) months birth")
        print("\(dToBirth) days to birth day")
        break
    } else {
        dToBirth += daysInMonths[i]
    }
}

//----------------------------------------------------------------

//Моё решение
let dayBirth = 9
let monthBirth = nameMonths[7]
var daysToBirth = 0

for i in 0..<nameMonths.count {
    if monthBirth == nameMonths[i] {
        
        daysToBirth += dayBirth
        print("\(nameMonths[i]) months birth")
        print("\(daysToBirth) days to birth day")
        break
        
    } else {
        daysToBirth += daysInMonths[i]
    }
    
}



//Optional array

//Первый вариант
//let optionalArray: [Int?] = [230, 76, 25, nil, 88, nil, 228, nil, nil]
let optionalArray = [230, 76, 25, nil, 88, nil, 228, nil, nil]

var sumOptArray = 0


//Optional binding
for i in 0..<optionalArray.count {
    if let x = optionalArray[i] {
        sumOptArray += x
        print("\nsumOptArray = \(sumOptArray)")
    } else {
        print("Cell \(i) in array have nil value")
    }
}

sumOptArray = 0



for i in optionalArray {
    if let y = i {
        sumOptArray += y
        print("sumOptArray \(sumOptArray)")
    } else {
        print("Variable have nil value ")
    }
}

sumOptArray = 0



// Force unwraping

sumOptArray = 0

for i in 0..<optionalArray.count {
    if optionalArray[i] != nil {
        sumOptArray += optionalArray[i]!
        print("\nIndex \(i) on array don't have nil value!")
    } else {
        print("Index \(i) on array havee nil value!")
    }
}
print("\nsumOptArray = \(sumOptArray)")




// Use ?? operator's
sumOptArray = 0

for i in 0..<optionalArray.count {
    sumOptArray += optionalArray[i] ?? 0
}
print("\nsumOptArray = \(sumOptArray)")





//Alphabet task
//1
let alphabet = "abcdefghijklmnopqrstuvwxyz"
var emptyAlphabet: [Character] = []

for i in alphabet {
    
    emptyAlphabet.append(i)
    
    
}
emptyAlphabet.reverse() // Разворот массива
print("\nVariant 1")
print("emptyAlphabet: \(emptyAlphabet)")


//2 Правильный ввариант
var emptyAlphabet_2 = [String]()

for i in alphabet {
    emptyAlphabet_2.insert(String(i), at: 0)
}
print("\nVariant 2")
print("Empty alphabet_2: \(emptyAlphabet_2)")


//3

var emptyAlphabet_3: [Character] = []

for i in alphabet {
    emptyAlphabet_3.insert(i, at: 0)
}
print("\nVariant 3")
print("Empty alphabet_3: \(emptyAlphabet_3)")




// Опциональный массив
let  asd = [1, nil, 2, nil]



let testArray1 = [1, 2, 34, 4]
let testArray2 = [9, 4, 5, 6,]
let testArray3 = [testArray1, testArray2]

var newTestArray = Array<Int>()




//My task

var check = 0
for i in 0..<testArray3.count {
    
    newTestArray.append(contentsOf: testArray3[i])
    //newTestArray.sorted()
    
    
    
    for y in check..<newTestArray.count {
        
        print("newTestArray - \(newTestArray[y])")
    }
    
    
    check += newTestArray.count
}

newTestArray.count
