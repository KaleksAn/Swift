//1. Создайте структуру студент.
//Добавьте свойства: имя, фамилия, год рождения, средний бал.
//Создайте несколько экземпляров этой структуры и заполните их данными.
//Положите их всех в массив (журнал).

struct DateBirth {
    var day: Int
    var month: Int
    var year: Int
}

struct Student {
    var name = "Name Student"
    var surname = "Surname student"
    var dateBirth: Int
    var rating = 0
    
    //var dateBirth: DateBirth
    //Вариант создания свойств без инициализации
//    var name: String
//    var surname: String
//    var dateBirth: Int
//    var rating: Int

}

var student_01 = Student(name: "Dmitriy", surname: "Kim", dateBirth: 1993, rating: 4)
var student_02 = Student(name: "Aleksandr", surname: "Kan", dateBirth: 1993, rating: 4)
var student_03 = Student(name: "Vladimir", surname: "Ten", dateBirth: 1993, rating: 3)
var student_04 = Student(name: "Andrey", surname: "Pak", dateBirth: 1994, rating: 4)
var student_05 = Student(name: "Igor", surname: "Kim", dateBirth: 1991, rating: 3)
var student_06 = Student(name: "Roman", surname: "Kan", dateBirth: 1995, rating: 3)
var student_07 = Student(name: "Mihail", surname: "Li", dateBirth: 1981, rating: 4)

var arrayStudents = [student_01, student_02, student_03, student_04, student_05, student_06, student_07]


//2. Напишите функцию, которая принимает массив студентов и выводит в консоль данные каждого. Перед выводом каждого студента добавляйте порядковый номер в “журнале”, начиная с 1.


func printStudents(in array: [Student]) {
    //var countNumber = 1
    for index in 0..<array.count {
        print("\(index + 1).Student info:\nName: \(array[index].name) \(array[index].surname)")
        print("Date birth: \(array[index].dateBirth)")
        print("Rating: \(array[index].rating)")
        print()
        //countNumber += 1
    }
    
}

printStudents(in: arrayStudents)


//3. С помощью функции sorted отсортируйте массив по среднему баллу, по убыванию и распечатайте “журнал”.

for i in arrayStudents.sorted(by: {$0.rating > $1.rating}) {
    print("Name: \(i.name) \(i.surname). Rating: \(i.rating)")
    //print()
}


//4. Отсортируйте теперь массив по фамилии (по возрастанию), причем если фамилии одинаковые, а вы сделайте так чтобы такое произошло, то сравниваются по имени. Распечатайте “журнал”.
print()


func sortStudents(in array: [Student]) {
//    array.sorted(by:) {
//        if $0.surname == $1.surname {
//            return $0.name < $1.surname
//        } else {
//            return $0.surname < $1.surname
//        }
//    }

    print("Sorted name array")
    for student in array.sorted(by: {
        if $0.surname == $1.surname {
            return $0.name < $1.name
        } else {
            return $0.surname < $1.surname
        }
    }) {
        print("Name: \(student.surname) \(student.name)")
    }
    
}

sortStudents(in: arrayStudents)



//let newArray = arrayStudents.sorted(by:) {
//    if $0.surname == $1.surname {
//               return $0.name < $1.surname
//            } else {
//               return $0.surname < $1.surname
//           }
//}
//
//
//for i in newArray {
//    print("Name \(i.surname) \(i.name)")
//}

print()


//5. Создайте переменную и присвойте ей ваш существующий массив. Измените в нем данные всех студентов. Изменится ли первый массив? Распечатайте оба массива.
var newStudentsArray = arrayStudents

newStudentsArray[0] = Student(name: "Victor", surname: "Son", dateBirth: 1994, rating: 5)
newStudentsArray[1] = Student(name: "Karina", surname: "Kim", dateBirth: 1993, rating: 3)
newStudentsArray[2] = Student(name: "Tatyana", surname: "Kim", dateBirth: 1994, rating: 4)

newStudentsArray[3].name = "Vladimir"
newStudentsArray[3].surname = "Pak"
newStudentsArray[3].dateBirth = 1991
newStudentsArray[3].rating = 4

newStudentsArray[4] = Student(name: "Sergey", surname: "Hegay", dateBirth: 1989, rating: 2)
newStudentsArray[5] = Student(name: "Roman", surname: "Kogay", dateBirth: 1992, rating: 2)
newStudentsArray[6] = Student(name: "Oleg", surname: "Ogay", dateBirth: 1996, rating: 1)


for index in 0..<arrayStudents.count {
    
    print("\(index + 1)Student from old array: \(arrayStudents[index].surname) \(arrayStudents[index].name)")
    print("Student from new array: \(newStudentsArray[index].surname) \(newStudentsArray[index].name)")
    print()
    
}



//6. Теперь проделайте все тоже самое, но не для структуры Студент, а для класса. Какой результат в 5м задании? Что изменилось и почему?

class Students {
    var name: String
    var surname: String
    var yearBirth: Int
    var rating: Int
    
    init(name: String, surname: String, yearBirth: Int, rating: Int) { //Инициализатор значений для свойств класса
        self.name = name
        self.surname = surname
        self.yearBirth = yearBirth
        self.rating = rating
    }
    
}


let stud_01 = Students(name: "Vitaliy", surname: "Shin", yearBirth: 1968, rating: 5)
let stud_02 = Students(name: "Victor", surname: "Shin", yearBirth: 1967, rating: 5)
let stud_03 = Students(name: "Vladislav", surname: "Ogay", yearBirth: 1975, rating: 4)
let stud_04 = Students(name: "Petr", surname: "Shetov", yearBirth: 1988, rating: 3)
let stud_05 = Students(name: "Aleksandr", surname: "Pushkin", yearBirth: 1799, rating: 5)

let arrayClassStudents = [stud_01, stud_02, stud_03, stud_04, stud_05]

print()
print("Old array students for class Students")
for i in arrayClassStudents {
    print("Student: \(i.name) \(i.surname). Info: DateBirth \(i.yearBirth) and rating \(i.rating)")
}

let newArrayStudents = arrayClassStudents

newArrayStudents[0].name = "Brian"
newArrayStudents[0].surname = "Johnson"
newArrayStudents[0].yearBirth = 2000
newArrayStudents[0].rating = 4

newArrayStudents[1].name = "Jack"
newArrayStudents[1].surname = "Black"
newArrayStudents[1].yearBirth = 1966
newArrayStudents[1].rating = 5

newArrayStudents[2].name = "Robs"
newArrayStudents[2].surname = "Trevors"
newArrayStudents[2].yearBirth = 1998
newArrayStudents[2].rating = 3

newArrayStudents[3].name = "Timofey"
newArrayStudents[3].surname = "Li"
newArrayStudents[3].yearBirth = 1992
newArrayStudents[3].rating = 4

newArrayStudents[4].name = "Mike"
newArrayStudents[4].surname = "Rodjers"
newArrayStudents[4].yearBirth = 1938
newArrayStudents[4].rating = 10


print()
print("Old array students for class Students")
for i in arrayClassStudents {
    print("Student: \(i.name) \(i.surname). Info: DateBirth \(i.yearBirth) and rating \(i.rating)")
}

print()
print("New array students for class Students")
for i in newArrayStudents {
    print("Student: \(i.name) \(i.surname). Info: DateBirth \(i.yearBirth) and rating \(i.rating)")
}



//7

class Chess {
    enum ChessColor: String {
        case white = "\u{25AB}"
        case black = "\u{25AA}"
    }
    
    enum ChessName: Int {
        case pawn
        case horse
        case elephant
        case rook
        case queen
        case king
    }
    
    
    
}


var pawn = Chess.ChessName.rook.rawValue
