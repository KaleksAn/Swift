//Switch



var age = 67

switch age {
    case 0...20:
        print("Hi buddy!")
        fallthrough // переход в селдующий кейс несмотря на условие
    case 21...30:
        print("I don't know you!")
    case 31...50:
        print("")
    case 51, 55, 56, 60:
        print("Is work!")
    default:
        print("not value")
}







//
mainLoop: for _ in 0...1000 {
    
    for i in 0..<20 {
        if i < 15 {
            continue
        }
        
        if i == 10 {
            break mainLoop
        }
        print(i)
    }
}



var name = "Alex"

switch name {
    case "Alex" where age < 50:
        print("Hi Alex!")
    case "Alex" where age >= 50:
        print("I don't know you")
    case "Alex":
        print("Hi Alex!")
    default:
        break
}



let tuple = (name, age)


switch tuple {
    case ("Alex", 60):
        print("Hi, Alex 60")
    case ("Alex", 55):
        print("Hi, Alex 55")
    case ("Alex", _):
        print("Hi, Alex!")
    default:
        break
}

//value binding with tuple in switch

switch tuple {
    case (_, let number) where number >= 65 && number <= 70:
        print("hi old man")
    default:
        break
}


let point = (5 , -6)

switch point {
    case let (x, y) where x==y:
        print("x == y")
    case let (x, y) where x == -y:
        print("x == -y")
    case let (_, y) where y < 0:
        print("y < 0")
    case (_, let y) where y == 100:
        print("y = 100")
    default:
        break
}

//old protocol Printable
let array: [CustomReflectable] = [5, 5.4, Float(5.4), "we"]

switch array[3] {
    case _ as Int: //wildCard
        print("Int")
    case let a as Float:
        print("Float \(a)")
    case let a as Double:
        print("Double \(a)")
    case _ as String:
        print("String")
    default:
        break
}



var opt1: Int? = 5
var opt2: Int? = 12

let newTuple = (opt1, opt2)

switch newTuple {
    case let (num1, num2) where num1 == 5 && num2 == 10:
        print("num1 = \(num1 ?? 0) num2 = \(num2 ?? 0)")
    case (_, let num2) where num2 == 12:
        print("num2 type: \(type(of: num2!))")
    default:
        break
}

//For in...

for index in 1...5 {
    print("\(index) умножить на 5 =  \(5 * index)")
}


let base = 3
let power = 10
var answer = 1

for _ in 1...power {
    answer *= base
}
print("\(base) в степени \(power) равно \(answer)")

//Half ramge
let minutes = 60
let minuteInterval = 5
for tickMark in stride(from: 0, to: minutes, by: minuteInterval) {
    print("\(tickMark)")
}

//Closed range

let hours = 12
let hourInterval = 3
for tickMark in stride(from: 3, through: hours, by: hourInterval) {
    print(tickMark)
}


//While
let finalSquare = 25
var board = [Int](repeating: 0, count: finalSquare + 1)
var square = 0
var diceRoll = 0

board[3] = 8
board[6] = 11
board[9] = 9
board[10] = 2
board[14] = -10
board[19] = -11
board[22] = -2
board[24] = -8

while square < finalSquare {
    diceRoll += 1
    if diceRoll == 7 {
        diceRoll = 1
    }
    square += diceRoll
    
    if square < board.count {
        square += board[square]
    }
}
print("Game over!")

// repeat - while
//Аналог do - while

var square2 = 0
var diceRoll2 = 0

repeat {
    square2 += board[square2]
    diceRoll2 += 1
    if diceRoll2 == 7 {
        diceRoll2 = 1
    }
    square2 += diceRoll2
} while square2 < finalSquare
print("Game Over!")




//Switch

let someCharacter: Character = "z"
switch someCharacter {
    case "a":
        print("This first letter of the alphabet")
    case "z":
        print("The last letter of the alphabet")
    default:
        print("Some other character")
}




let anotherCharacter: Character = "k"

switch anotherCharacter {
    case "A", "a":
        print("This first letter of the alphabet")
        fallthrough//Оператор проваливания
    case "Z", "z":
        print("This lastt letter of the alphabet")
    default:
        print("Some otheer character")
}


//Range in switch
let approximateCount = 62
let countedThings = "moons orbiting Saturn"
var naturalCount: String

switch approximateCount {
    case 0:
        naturalCount = "no"
    case 1..<5:
        naturalCount = "a few"
    case 5..<12:
        naturalCount = "several"
    case 12..<100:
        naturalCount = "dozens of"
    case 100..<1000:
        naturalCount = "hundreds of"
    default:
        naturalCount = "many"
}

print("There are \(naturalCount) \(countedThings)")



//Tuples in switch
let somePoint = (1, 1)

switch somePoint {
    case (0, 0):
        print("\(somePoint) is at the origin")
    case (_, 0):
        print("\(somePoint) is on the x-axis")
    case (0, _):
        print("\(somePoint) is on the y-axis")
    case (-2...2, -2...2):
        print("\(somePoint) is inside the box")
    default:
        print("\(somePoint) is outside of the box")
}


//Value binding

let anotherPoint = (2, 0)
switch anotherPoint {
    case (let x, 0):
        print("on the x-axis with an x value of \(x)")
    case (0, let y):
        print("on the y-axis with a y value of \(y)")
    case let (x, y):
        print("somewhere else at (\(x), \(y)")
    //default:
        //break
}

//where
let yetAnotherPoint = (1, -1)
switch yetAnotherPoint {
    case let (x, y) where x == y:
        print("(\(x), \(y)) is on the line x == y")
    case let (x, y) where x == -y:
        print("(\(x), \(y)) is on the line x == -y")
    case let (x, y):
        print("(\(x), \(y)) is just some arbitary point")
    //default:
      //  <#code#>
}



//Compound case
//Составные

let someCharacter2: Character = "e"

switch someCharacter2 {
    case "a", "e", "i", "o", "u":
        print("\(someCharacter2) is vowel")
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
         "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z":
        print("\(someCharacter2) is a constant")
    default:
        print("\(someCharacter2) is not a vowel or a consonant")
                        
}



//value binding and few condition
let stillAnotherPoint = (9, 0)

switch stillAnotherPoint {
    case (let distance, 0), (0, let distance):
        print("On an axis, \(distance) from the origin")
    default:
        print("Not on an axis")
}


let myPoints = ("Q", "S")

switch myPoints {
    case (let point, "Y"), ("A", let point):
        print("Point \(point)")
    case ("K", let point), (let point, "W"):
        print("Point \(point)")
    case ("Q", let point), ("L", let point):
        print("Test point \(point)")
    case let (point1, point2):
        print("New ponts \(point1), \(point2)")
   
}


//Control operators


//Continue
let puzzleInput = "great minds think a like"
var puzzleOutput = ""
let charactersToRemove: [Character] = ["a", "e", "i", "o", "u", " "]
for character in puzzleInput {
    if charactersToRemove.contains(character) {
        continue
    } else {
        puzzleOutput.append(character)
    }
}
print(puzzleOutput)




//Break
let numberSymbol: Character = "三"

var possibleIntegerValue: Int?
switch numberSymbol {
    case "1", "١", "一", "๑":
        possibleIntegerValue = 1
    case "2", "٢", "二", "๒":
        possibleIntegerValue = 2
    case "3", "٣", "三", "๓":
        possibleIntegerValue = 3
    case "4", "٤", "四", "๔":
        possibleIntegerValue = 4
    default:
        break
}

if let integerValue = possibleIntegerValue {
    print("The integer value of \(numberSymbol) is \(integerValue)")
} else {
    print("An integer value could not be found for \(numberSymbol)")
}



//Fallthrough
let integerToDescribe = 5
var description = "The number \(integerToDescribe) is"
switch integerToDescribe {
    case 2, 3, 5, 7, 11, 13, 17, 19:
        description += " a prime number, and also"
        fallthrough
    default:
        description += " an integer"
}
print(description)




//Marker's


let finalSquare1 = 25
var board3 = [Int](repeating: 0, count: finalSquare1 + 1)
board3[03] = +08
board3[06] = +11
board3[09] = +9
board3[10] = +02
board3[14] = -10
board3[19] = -11
board3[22] = -02
board3[24] = -08
var newSquare = 0
var newDiceRoll = 0


gameLoop: while newSquare != finalSquare1 {
    newDiceRoll += 1
    if newDiceRoll == 7 {
        newDiceRoll = 1
    }
    switch newSquare + newDiceRoll {
        case finalSquare1:
            break gameLoop
        case let newSqr where newSqr > finalSquare1:
            continue gameLoop
        default:
            newSquare += newDiceRoll
            newSquare += board3[newSquare]
    }
}
print("Game over!")


//Guard

func greet(person: [String: String]) {
    guard let name = person["name"] else {
        return
    }
    
    print("Hi \(name)!")
    
    guard let location = person["location"] else {
        print("Надеюсь у тебя там хорошая погода")
        return
    }
    
    print("Надеюсь в \(location) хорошая погода.")
    
}

greet(person: ["name": "John"])

greet(person: ["name": "", "location": "Cupertino"])







//My Test
let myConst = 15
var myCount = 0

repeat {
    myCount += 1
    print("My count = \(myCount)")
} while myCount < myConst





for i in 200...300 {
    print("i = \(i)")
}

let letters = "a"..."z"

letters.contains("e")







//Homework for Swift Developers Group
//Task 1

myMark: for i in 0...200 {
    print(" i in Loop for = \(i)")
    mySecondMark:   for y in 0...20 {
        if y == 15 {
            //break myMark
            //break
            continue mySecondMark
        }
        print("y in Loop for = \(y)")
    }
}


//Task_02

var myAge = 27
let youName = "John"

//for if-else if
if myAge == 7 {
    print("You go to school!")
} else if myAge == 16 || myAge == 17 {
    print("You can go to сollege or universite")
} else if myAge == 65 || myAge == 60 {
    print("You pension!")
} else {
    print("Invalid value")
}


//for switch
switch myAge {
    case 6, 7, 8:
        print("You can go to school!")
    case 16, 17, 18:
        print("You can go to college or universite")
    case 19...30:
        print("You just young!)")
    case 55...65:
        print("You pension!")
    default:
        print("Please, valid value!")
}


switch (myAge, youName) {
    case let (18...30, name) where name == "Alex":
        print("You my fried!")
    case (18...30, let name) where name == "Dmitriy":
        print("You my brother!")
    case (_, "John"), (_, "Fred"), (_, "Ferz"), (_, "Markeloff"):
        print("You my teammate on CS GO!")
    default:
        print("i don't know you!")
}


//My Test
//Create array with letters and array consonats
let letA = "a".unicodeScalars
let startAval = letA[letA.startIndex].value
var arrayConsonats = [Character]()

let arrayLetters: [Character] = (0..<26).map{
    i in Character(UnicodeScalar(startAval + i)!)
}

for i in arrayLetters {
    switch i {
        case "a", "e", "o", "i", "u":
            continue
        case "b", "c", "d", "f", "g", "k", "l", "m", "n", "y", "t", "q", "p", "x", "w", "z", "s", "v":
            arrayConsonats.append(i)
        default:
            continue
    }
}


for i in arrayConsonats {
    print("i = \(i)")
}


//Task 03
//Use loop for
//Use closed range

print("\nTask 03")
print("Use all loop's for")
for i in 0...30 {
    print("\(i)")
    if i == 30 {
        print("GO!")
    }
}

//Just use loop without var i
print("\nPrint Hello World 10 time")
for _ in 0...10 {
    print("Hello World!")
}


//half-closed range on loop
//Print half-closed range

for i in 0..<10 {
    print("i = \(i)")
}

for i in 0..<arrayConsonats.count {
    print("value from array \(arrayConsonats[i])")
}


//Use stride on loop for

//half-closed range in stride loop for
for i in stride(from: 30, to: 0, by: -2) {
    print("Stride i equal \(i)")
}

for i in stride(from: 0, to: arrayConsonats.count - 1, by: 2) {
    print("Half-closed stride on array: \(arrayConsonats[i])")
}



//Closed range
for i in stride(from: 0, through: 15, by: 1) {
    print("Half-stride range on loop: \(i)")
}

for i in stride(from: arrayConsonats.count-1, through: 0, by: -3) {
    print("Print consonant array with stride: \(arrayConsonats[i])")
}



//Task 04

var myRating = Int.random(in: 1...13)

//if -else
if myRating == 1 || myRating == 2 || myRating == 3 || myRating == 4 || myRating == 5 {
    print("Exam FILED!")
} else if myRating == 6 || myRating == 7 {
    print("Satisfactorily")
} else if myRating == 8 || myRating == 9 || myRating == 10 || myRating == 11 {
    print("You rating is GOOD!")
} else if myRating == 12 {
    print("Perfect!")
} else {
    print("Invalid value")
}


//Switch

switch myRating {
    case 1, 2, 3, 4, 5:
        print("Exam FILED!")
    case 6, 7:
        print("Satisfactorily")
    case 8, 9, 10, 11:
        print("You rating is GOOD!")
    case 12:
        print("Perfect!")
    default:
        print("Please, enter valid value on switch")
}


//Task 05
var myFamily = ["Alexander", "Vladimir", "Elena", "Igor", "Irina", "Tatiana", "Alexey", "Evgeniy", "Alena", "Nadejda"]
var newFamilyArray = [String]()

for i in 0...myFamily.count - 1 {
    newFamilyArray.append(myFamily[i])
}
newFamilyArray.sorted(by: >)




//myFamily.sort()



//Alexey Skutarenko
//Task 01

//Ver 1.0
var consonants = 0
var vowels = 0
var otherSymbols = 0

var symbols = (consonants: 0, vowels: 0, otherSymbols: 0)

let myString = """
                 One morning, when Gregor Samsa woke from troubled dreams, he found himself transformed in his bed into a horrible vermin.
                 He lay on his armour-like back, and if he lifted his head a little he could see his brown belly, slightly domed and divided by a
                """

for i in myString {
    switch i {
        case "A", "E", "U", "I", "O":
            //vowels += 1
            symbols.vowels += 1
        case "a", "e", "u", "i", "o":
            symbols.vowels += 1
        case "B", "C", "D", "F", "G", "P", "K", "L", "M", "R", "S", "H", "J", "T", "Q", "V", "W", "Y", "Z", "N":
            symbols.consonants += 1
        case "b", "c", "d", "f", "g", "p", "k", "l", "m", "r", "s", "h", "j", "t", "q", "v", "w", "y", "z", "n":
            symbols.consonants += 1
        default:
            symbols.otherSymbols += 1
    }
}

print("\n\t\t\tStatistics:")
print("Vowel's: \(symbols.vowels)")
print("Consonant's: \(symbols.consonants)")
print("Other symbol's: \(symbols.otherSymbols)")


//ver 2.0
//let testtest = ["a", "b"]
//consonants = 0
//vowels = 0
//otherSymbols = 0
//let alphabet = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
//
//for i in myString {
//    for _ in 0..<alphabet.count {
//        switch i {
//            case :
//                break
//                case alphabet[2]
//            default:
//                <#code#>
//        }
//    }
//}



//Task 02
var numAge = 22

switch numAge {
    case 1...6:
        print("You child")
    case 7..<17:
        print("You school-child")
    case 17...21:
        print("You student")
    case 21...30:
        print("You just young man")
    case 30..<55:
        print("Family man")
    case 55...70:
        print("You just pension man")
    default:
        print("Invalid value")
}


//Task 03
