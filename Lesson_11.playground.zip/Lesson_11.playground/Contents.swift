//Clousers

let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backward(_ s1: String, _ s2: String) -> Bool {
    return s1 > s2
}

var reversedNames = names.sorted(by: backward)



//Использование замыканий в качестве передаваемого параметра вместо функции
reversedNames = names.sorted(by: {(s1: String, s2: String) -> Bool in return s1 > s2})

print(reversedNames)


//Этот параметр функции, ожидает функцию типа  (String, String) -> Bool
//Это означает, что типы (String, String) -> Bool можно не писать в объявлении замыкающего выражения
//Стрелка результата -> и скобки вокруг имён параметров могут быть опущены
reversedNames = names.sorted(by: {s1, s2 in return s1 > s2})






//Неявные возвращаемые значения из замыканий с одним выражением
//Поскольку тело замыкания содержит одно выражение (s1 > s2), которое возвращает Bool значение, то нет никакой двусмысленности, и ключевое слово return можно опустить.

reversedNames = names.sorted(by: {s1, s2 in s1 > s2})



//Сокращенные имена параметров
//Здесь, $0 и $1 обращаются к первому и второму String параметру замыкания.
/*
 Если вы используете эти сокращенные имена параметров с вашим замыкающим выражением, вы можете пропустить список параметров замыкания из его объявления, а количество и тип сокращенных имен параметров будет выведено из ожидаемого типа метода. Ключевое слово in также может быть опущено, поскольку замыкающее выражение полностью состоит из его тела:
 */
reversedNames = names.sorted(by: {$0 > $1})


//Операторные функции
reversedNames = names.sorted(by: >)


//Последующее замыкание
//Создание функции с принимающим параметром тип-функции () -> Void
func someFunctionThatTakesAClosure(closure: () -> Void) {
    
}



someFunctionThatTakesAClosure (closure: {
//тело замыкания
    
})


// Вот как вы вызываете эту функцию с использованием последующего замыкания:
someFunctionThatTakesAClosure() {
    
    // тело последующего замыкания
    
}


reversedNames = names.sorted(){$0 > $1}

/*Если выражение замыкания является единственным аргументом функции, и вы пишете его используя синтаксис последующего замыкания, то вы можете опустить написание круглых скобок вызова самой функции после ее имени
*/

reversedNames = names.sorted{$0 > $1}



//Перевод цифр в текст при помощи замыкания
let digitsNames = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4: "Four", 5: "Five", 6: "Six", 7: "Seven", 8: "Eight", 9: "Nine"]

let numbers = [16, 58, 510]


let strings = numbers.map {(number) -> String in
    var number = number
    var output = ""
    repeat {
        output = digitsNames[number % 10]! + output //16 % 10 = 6
        number /= 10 // 16 / 10 = 1
    } while number > 0
    return output
}


16 % 10
58 % 10
510 % 10

1 / 10

/*
func loadPicture(from server: Server, completion: (Picture) -> Void, onFailure: () -> Void) {
    if let picture = download("photo,jpg", from: sever) {
        completion(picture)
    } else {
        onFailure()
    }
}
 
 
 loadPicture(from: someServer) { picture in
  someView.currentPicture = picture} onFailure: {
    print("Could't download the next picture")
 }
 
*/





//Захват значений


func makeIncrementer(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementer
}



let incrementByTen = makeIncrementer(forIncrement: 10)
incrementByTen()
incrementByTen()
incrementByTen()


let incrementBySeven = makeIncrementer(forIncrement: 7)
incrementBySeven()


incrementByTen()


//Замыкания - ссылочный тип

let alsoIncrementByTen = incrementByTen
alsoIncrementByTen()
incrementByTen()



//Сбегающие замыкания

var completionHandlers: [() -> Void] = []
func someFunctionWithEscapingClousere(completionHandler: @escaping () -> Void) {
    completionHandlers.append(completionHandler)
}



func someFunctionWithNonescapingClosure(closure: () -> Void)  {
    closure()
}

class SomeClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClousere {self.x = 100}
        someFunctionWithNonescapingClosure {x = 200}
    }
}


let instance = SomeClass()
instance.doSomething()
print(instance.x)

completionHandlers.first?()
print(instance.x)



class SomeOtherClass {
    var x = 10
    func doSomething() {
        someFunctionWithEscapingClousere {[self] in x = 100}
        someFunctionWithNonescapingClosure {x = 200}
    }
}



//Автозамыкания (autoclosures)

var customersInLine = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]
print(customersInLine.count)

let customerProvider = {customersInLine.remove(at: 0)}
print(customersInLine.count)


print("Now serving \(customerProvider())!")
print(customersInLine.count)

func serve(customer customerProvider: () -> String) {
    print("Now serving \(customerProvider())")
}

serve(customer: {customersInLine.remove(at: 0)})

//-----------------------------------

func serve(customer customerProvider: @autoclosure () -> String) {
    print("Now serving \(customerProvider())!")
}

serve(customer: customersInLine.remove(at: 0))

print(customersInLine.count)



//-------------------------------------

var customerProviders: [() -> String] = []

func collectCustomerProviders(_ customerProvider: @autoclosure @escaping () -> String) {
    customerProviders.append(customerProvider)
}

collectCustomerProviders(customersInLine.remove(at: 0))
collectCustomerProviders(customersInLine.remove(at: 0))

print("Collected \(customerProviders.count) closures")

for customerProvider in customerProviders {
    print("Now serving \(customerProvider())!")
}


/*

let str1 = "Relock"
str1.count

func terTest(str: String) -> String {
    return str
}

func func1(str1: String, str2: String) -> (_ str3: String) -> String {
    
    func test(name: String) -> String {
        return ("Hello \(name)! It's ok! \(str1) and \(str2) ")
    }
    
    return terTest
}


let testFunc = func1(str1: "Bob", str2: "Jack")

testFunc("Kim")
*/






//По книге Василия Усова

//Замыкания - это безымянные функции

//Безымянная функция в качестве значения константы
let functionInLet = {return 1 > 0}
functionInLet()

//Sort array
var wallet = [10, 50, 100, 100, 5000, 100, 50, 50, 500, 100, 1000, 1000, 5, 200]

func handle100(wallet: [Int]) -> [Int] {
    var returnWallet = [Int]()
    for banknote in wallet {
        if banknote == 100 {
            returnWallet.append(banknote)
        }
    }
    return returnWallet
}

handle100(wallet: wallet)


func handleMore1000(wallet: [Int]) -> [Int] {
    var returnWallet = [Int]()
    for banknote in wallet {
        if banknote >= 1000 {
            returnWallet.append(banknote)
        }
    }
    return returnWallet
}

handleMore1000(wallet: wallet)


//Создание двух функций в качестве аргументов параметра для функции сравнения банкнот

func handle(wallet: [Int], closure: (Int) -> Bool) -> [Int] {
    var returnWallet = [Int]()
    for banknote in wallet {
        if closure(banknote) {
            returnWallet.append(banknote)
        }
    }
    return returnWallet
}


func compare100(banknote: Int) -> Bool {
    return banknote == 100
}

func compare1000(banknote: Int) -> Bool {
    return banknote == 1000
}


let resultWalletOne = handle(wallet: wallet, closure: compare100)
let resultWalletTwo = handle(wallet: wallet, closure: compare1000)

print("Result wallet one: \(resultWalletOne)")
print("result wallet two: \(resultWalletTwo)")



//Замена функций на клоужеры

handle(wallet: wallet, closure: {(banknote: Int) -> Bool in return banknote >= 1000})
handle(wallet: wallet, closure: {(banknote: Int) -> Bool in return banknote == 100})
handle(wallet: wallet, closure: {$0 == 10}) //Сокращённая запись

let banknote50 = handle(wallet: wallet, closure: {(cash: Int) -> Bool in return cash == 50})
print(banknote50)


//Возможности замыканий
//Пропуск указания типов

handle(wallet: wallet, closure: {banknote in return banknote >= 1000}) // Входной параметр без указания типа

// Неявное возвращение без оператора return
handle(wallet: wallet, closure: {banknote in banknote >= 1000})
handle(wallet: wallet, closure: {banknote in banknote == 20})

//Сокращённые имена параметров в замыканиях
handle(wallet: wallet, closure: {$0 >= 1000})
handle(wallet: wallet, closure: {$0 == 5})
handle(wallet: wallet, closure: {$0 == 1})
handle(wallet: wallet, closure: {(banknote: Int) -> Bool in
        let resultBool = banknote < 10
        return resultBool}) //Длинная запись

handle(wallet: wallet, closure: {$0 < 5}) // короткая запись



//Вынос замыкания за скобки
//Если входной параметр в виде функции находится в конце списка параметров, то при реализации, замыкание можно вынести за скобки параметров
//Если возвращаемое значение замыкания, содержит одно выражение, то можно не использовать слово return

handle(wallet: wallet){$0 >= 1000}
handle(wallet: wallet){(banknote: Int) -> Bool in return banknote >= 1000}
handle(wallet: wallet){(nominal: Int) -> Bool in
    var result = Bool()
    result = nominal <= 2
    return result
}


handle(wallet: wallet){banknote in
    for number in Array(arrayLiteral: 100, 500) {
        if number == banknote {
            return true
        }
    }
    return false
}


let sucessBanknotes  = handle(wallet: wallet){[100, 200].contains($0)}
sucessBanknotes

//let arrayTest = Array(arrayLiteral: 100, 200, 300)



//Вынос нескольких замыканий за скобки при условии, что они находятся в конце списка параметров

func networkQuery(url:String, success: (String) -> (), error: (Int) -> ()) {
    //any code
}

//классический вариант передачи параметров (Замыканий)
networkQuery(url: "https://google.com", success: {data in}, error: {errorCode in})

//Новый вариант
networkQuery(url: "https://weather.com"){data in} error: { errorCode in}


//Безымянные функции в параметрах
//Явное указание типа параметра
let closure: () -> () = {
    print("Замыкающие выражение")
}
closure()

//Неявное указание типа параметра
let closure_2 = {
    print("Hello World")
}

closure_2()


//Передача в функцию строкового значения
let closurePrint: (String) -> Void = {text in print(text)}
closurePrint("Hello!")

let myString: (_ str1:String, _ str2:String) -> String = {text1, text2 in
    return "\(text1) \(text2)"
}

print(myString("Hello", "World2"))


let testBool: (_ number: Int, _ number2: Int) -> Bool = {$0 >= $1}
testBool(23, 22)




//Передача в функцию целочисленных значений
var sum: (_ numOne: Int, _ numTwo: Int) -> Int = {
    $0 + $1
}



//My test
let var1: (String) -> String = {anyStr in return "Any phrase for \(anyStr)"}

func closureTest(str: String, closure: (String) -> String) -> String {
    
    return "Hello \(str)! \(closure(str)) "
}

closureTest(str: "Frank", closure: var1)


//Пример использования замыканий при сортировке массива

let array = [1, 44, 81, 4, 277,  50, 101, 51, 8]

var sortedArray = array.sorted(by: {(first, second) -> Bool in return first < second})
print("Sorted array: \(sortedArray)")

sortedArray = array.sorted(by: {$0 < $1})// сокращённая запись
print("Sorted array: \(sortedArray)")

array.sorted(by: {$0 < $1})

sortedArray = array.sorted(by: >)//ещё более короткая запись
print("Array \(sortedArray)")



//Захват внешних переменных
var a = 1
var b = 2
let closureSum: () -> Int = {
    a + b
}
closureSum()

a = 5
b = -20

closureSum()

//Захват первоначальных внешних значений

var x = 10
var y = 15
let closureSum2: () -> Int = {[x, y] in return x + y}
print("Closure sum 2: \(closureSum2())")

x = 40
y = 23

print("Closure sum 2: \(closureSum2())")


//Захват вложенной функцией

func makeincrement(forIncrement amount: Int) -> () -> Int {
    var runningTotal = 0
    func increment() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return increment
}

var incrementTen = makeincrement(forIncrement: 10)
var incrementSeven = makeincrement(forIncrement: 7)

incrementTen()
incrementTen()
incrementTen()

incrementSeven()
incrementSeven()
incrementSeven()

incrementTen()
incrementSeven()



//Передача замыканий по ссылке

var incrementFive = makeincrement(forIncrement: 5)
var copyIncrementFive = incrementFive

incrementFive()
copyIncrementFive()
incrementFive()
copyIncrementFive()



func testReference(num: Int, num2: Int) -> () -> Int {
    var res = 0
    func add() -> Int {
        res = res + num2 + num
        return res
    }
    
    return add
}

let ref = testReference(num: 2, num2: 3)
let ref2 = ref

ref()
ref2()
ref()


//АВТОЗАМЫКАНИЯ
var arrayOfNames = ["Helga", "Bazil", "Alex", "Bob"]
func printName(nextName: String) {
    print("Hello \(nextName)")
}

printName(nextName: arrayOfNames.remove(at: 0))

//Ленивое вычисление
func printName2(nextName: () -> String) {
    print(nextName())
}

printName2(nextName: {arrayOfNames.remove(at: 0)})


//Пример автозамыкания
func printName3(nextName: @autoclosure () -> String) {
    print(nextName())
}

printName3(nextName: arrayOfNames.remove(at: 0))



//СБЕГАЮЩИЕ ЗАМЫКАНИЯ
//Это тот вид замыканий который необходимо сохранить, и использовать повторно.
//Для создания сбегающего замыкания, необходимо указать @escaping перед типом функции (замыкания) при создании параметра функции

var arrayOfClosures: [() -> Int] = []

func addNewCloosureInArray(_ newClosure: @escaping () -> Int) {
    arrayOfClosures.append(newClosure)
}

addNewCloosureInArray({return 100})
addNewCloosureInArray({() -> Int in return 25})
addNewCloosureInArray{return 1000}

arrayOfClosures[0]()
arrayOfClosures[1]()
arrayOfClosures[2]()

print(arrayOfClosures[0]())



var arrayMyTest: [(String, String) -> String] = []

func testStr(str: @escaping (_ str1: String, _ str2: String) -> String) -> String {
    
    arrayMyTest.append(str)
    let result = str("My ", "TEST")
    return result
}


testStr(str: {str1, str2 in
            let phrase = str1 + str2
            return phrase
})

arrayMyTest[0]("Bob", "Jack")
arrayMyTest.count


let testClosure = {(x: Int, y: Int) -> Int in
    return x + y
}(2, 3)

























































