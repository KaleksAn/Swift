

struct TimesTable {
    let multipler: Int
    subscript(index: Int) -> Int {
        return multipler * index
    }
}

let threeTimesTable = TimesTable(multipler: 3)
print("Шесть умножить на три будет \(threeTimesTable[6])")
print("Шесть умножить на три будет \(threeTimesTable[7])")

var numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
numberOfLegs["bird"] = 2


struct Matrix {
    let rows: Int, columns: Int
    var grid: [Double]
    init(rows: Int, columns: Int) {
        self.rows = rows
        self.columns = columns
        grid = Array(repeating: 0.0, count: rows * columns)
    }
    
    func indexIsValid(row: Int, column: Int) -> Bool {
        return row >= 0 && row < rows && column >= 0 && column < columns
    }
    
    subscript(row: Int, column: Int) -> Double {
        get {
            assert(indexIsValid(row: row, column: column), "Index out of range")
            return grid[(row * columns) + column]
        }
        
        set {
            assert(indexIsValid(row: row, column: column), "Index out of range")
            grid[(row * columns) + column] = newValue
        }
    }
    
}

var matrix = Matrix(rows: 2, columns: 2)

matrix[0, 1] = 1.5
matrix[1, 0] = 3.2
matrix[1, 1] = 5.5
matrix[0, 1]


enum ABC {
    subscript(n: Int) -> Bool {
        return true
    }
}

//Chess
class ChessMan {
    enum ChessmanType {
        case king, castle, bishop, pawn, knight, queen
    }
    
    enum ChessmanColor {
        case black, white
    }
    
    let type: ChessmanType
    let color: ChessmanColor
    var coordinates: (String, Int)?
    let figureSymbol: Character
    
    init(type: ChessmanType, color: ChessmanColor, figure: Character) {
        self.type = type
        self.color = color
        figureSymbol = figure
    }
    
    init(type: ChessmanType, color: ChessmanColor, figure: Character, coordinates: (String, Int)) {
        self.type = type
        self.color = color
        figureSymbol = figure
        setCoordinates(char: coordinates.0, num: coordinates.1)
    }
    
    func setCoordinates (char c: String, num n: Int) {
        coordinates = (c, n)
    }
    
    func kill() {
        coordinates = nil
    }
}


class GameDesk {
    var desk: [Int: [String: ChessMan]] = [:]
    init() {
        for i in 1...8 {
            desk[i] = [:]
        }
    }
    
    subscript(alpha: String, number: Int) -> ChessMan? {
        get {
            return self.desk[number]![alpha]
        }
        set {
            if let chessman = newValue {
                self.setChessman(chess: chessman, coordinates: (alpha, number))
            } else {
                self.desk[number]![alpha] = nil
            }
        }
    }
    
    func setChessman(chess: ChessMan, coordinates: (String, Int)) {
        let rowRange = 1...8
        let colRange = "A"..."H"
        if (rowRange.contains(coordinates.1) && colRange.contains(coordinates.0)) {
            self.desk[coordinates.1]![coordinates.0] = chess
            chess.setCoordinates(char: coordinates.0, num: coordinates.1)
        } else {
            print("Coordinates out of range")
        }
    }
    
}

var game = GameDesk()
var queenBlack = ChessMan(type: .queen, color: .black, figure: "\u{265B}", coordinates: ("A", 6))

game["C", 5] = queenBlack
game["C", 5]
game["C", 5] = nil
game["C", 5]



class MultyTest {
    var number: Int
    init(num: Int) {
        self.number = num
    }
    
    subscript(num: Int) -> Int {
        
        get {
            return num * number
        }
        
        set {
            number = newValue
        }
    }
    
}


let firstTest = MultyTest(num: 5)
firstTest[5]
firstTest[5] = 23123
firstTest.number




func chessBoard(x: Int, y: String) {
    let alphabet = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
   // var array = Array(repeating: 0, count: x * y)
   // var desk = ""
    var horizont = 0
    
    if let y = alphabet[y] {
        horizont = y
    }
    
    for x in 1...x {
        for y in 1...horizont {
            print(color(n1: y, n2: x), separator: "", terminator: "")
        }
        print()
    }
    
}



chessBoard(x: 8, y: "C")


//////////////////////////////////////////////////////////
print("\n\n\n")

class ChessBoard {
    var number: Int
    var letter: String
    
    init(number: Int, letter: Character) {
        self.number = number
        self.letter = String(letter)
    }
    
    subscript(number: Int, letter: String) -> String {
        get {
            return color(n1: checkNumber(check: number), n2: checkLetter(letter: letter))
        }
    }
    
    
//Print board
    func printBoard() {
        let x = checkLetter(letter: letter)
        let y = checkNumber(check: number)
        
        if x == nil || y == nil {
            print("DANGER! CRITICAL ERROR! CAUTION: Check your enter values!")
        } else {
        
        for horizont in 1...x! {
            for vertical in 1...y! {

                print(color(n1: horizont, n2: vertical), separator: "", terminator: "")
            }
            print()
        }
        
        }
    }
    
    
//Check letter
    func checkLetter(letter: String) -> Int? {
        let alphabet = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
        
//        guard alphabet[letter] != nil else {
//            return 8
//        }
        
        let key = letter.uppercased()
        return alphabet[key]
        
    }
    
    
//Check number
    func checkNumber(check number: Int) -> Int? {
        switch number {
            case let value where value >= 1 && value <= 8:
                return value
            default:
                return nil
        }
    }
 
    
}

//Color Function
func color(n1: Int?, n2: Int?) -> String {
    
    guard !(n1 == nil && n2 == nil) else {
        return "nil"
    }
   
    /*
    if n1! % 2 == n2! % 2 {
        return "\u{2B1B}"
    } else if n1! % 2 != n2! % 2 {
        return "\u{2B1C}"
    } else {
        return "nil"
    }
 */
    
    return n1! % 2 == n2! % 2 ? "\u{2B1B}" : "\u{2B1C}"
    
}



let board_1 = ChessBoard(number: 8, letter: "H")
board_1.printBoard()

board_1[1, "h"]
board_1[8, "h"]
board_1[2, "d"]
board_1[6, "a"]
board_1[0, "Ф"]




///////////////////////////////////////////////////////////////
print()



//class CreateMap {
//    var width: Int
//    var hight: Int
//
//    init(w: Int, h: Int) {
//        self.width = w
//        self.hight = h
//    }
//
//
//
//    func printMap(hero: Symbol? = nil) {
//        for x in 1...width {
//            for y in 1...hight {
//                print(cellValue(hero: hero, value_X: x, value_Y: y), separator: "", terminator: "")
//            }
//            print()
//        }
//    }
//
//
//    func cellValue(hero: Symbol?, value_X: Int, value_Y: Int) -> String {
//        guard hero != nil else {
//            return "\u{2B1C}"
//        }
//
//        let symbol = hero!
//
//        switch symbol {
//            case let .figure(img, x, y) where img.rawValue == "\u{274E}" && x == value_X && y == value_Y :
//                return "\u{274E}"
//            case let .figure(img, x, y) where img.rawValue == "\u{2705}" && x == value_X && y == value_Y:
//                return "\u{2705}"
//
//            default:
//                return "\u{2B1C}"
//        }
//
//    }
//
//}
//
//
//class Figures {
//    enum Heroes: String {
//        case hero_1 = "\u{274E}"
//        case hero_2 = "\u{2705}"
//    }
//
//    var type: Heroes
//    var positionX: Int
//    var positionY: Int
//
//    init(hero: Heroes, x: Int, y: Int) {
//        self.type = hero
//        self.positionX = x
//        self.positionY = y
//    }
//
//}
//
//
//
//enum Symbol {
//    enum Image: String {
//        case hero_1 = "\u{274E}"
//        case hero_2 = "\u{2705}"
//    }
//
//    case figure (symbol: Image, x: Int, y: Int)
//
//
//}
//
//
//
//
//let test = Symbol.figure(symbol: .hero_1, x: 5, y: 5)
//
//
//
//let d = CreateMap(w: 5, h: 5)
//d.printMap()
//
//
//let hero_1 = Figures(hero: .hero_1, x: 3, y: 2)
//
//
//print("\u{274E}")
//print(hero_1.type.rawValue)
//
//d.printMap(hero: test)





//Не совсем верно выполнено

enum Icons: String {
    case color = "\u{2B1C}"
    case cross = "\u{274E}"
    case null = "\u{2705}"
}

class Board {
    static let width = 5
    static let height = 5
    
    var x: Int {
        didSet {
            if x < 0 || x > Board.width {
                x = Board.width
            }
        }
    }
    
    var y: Int {
        didSet {
            if y < 0 || y > Board.height {
                y = Board.height
            }
        }
    }
    var symbol: Icons
    var memory: [String: Icons] = [:]
    
    init(x: Int, y: Int, img: Icons? = .color) {
        self.x = x
        self.y = y
        self.symbol = img!
        self.memory["\(x) \(y)"] = img
    }
    
   func printBoard() {
        for h in 1...Board.width {
            for v in 1...Board.height {
                
                
                let result = memory["\(h) \(v)"] != nil ? memory["\(h) \(v)"] : checkCell(num1: h, num2: v)
                
                print(result!.rawValue, separator: "", terminator: "")
            }
            print()
        }
    print()
    }
    
   func checkCell(num1: Int, num2: Int) -> Icons {
        let key = "\(num1) \(num2)"
        
        guard memory[key] == nil else {
            return memory[key]!
        }
        
        switch (num1, num2) {
            case let (h, v) where h == x && v == y:
                memory[key] = symbol
                return symbol
            default:
                return Icons.color
        }
    }
    
    func clearMap() {
        x = 0
        y = 0
        symbol = .color
        memory.removeAll()
    }
    
    
    subscript(n1: Int, n2: Int) -> Icons {
    
        get {
            let key = "\(n1) \(n2)"
            
            if memory[key] == nil {
                return .color
            } else {
                return memory[key]!
            }
        }
        set {
            let key = "\(n1) \(n2)"
            symbol = newValue
            memory[key] = symbol

            
        }
    }
    
}






let test = Board(x: 1, y: 3, img: .cross)
let testt2 = Board(x: 1, y: 1, img: .null)

//test.printBoard()
test[1,1] = .cross
test[1,2] = .cross
//test[1,3] = .null
test[1,4] = .cross

test.printBoard()
test.clearMap()
test.printBoard()
