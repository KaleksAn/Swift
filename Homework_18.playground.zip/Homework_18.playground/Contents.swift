
//Task 1

class Artist {
    var name: String = ""
    var surname: String = ""
    
    init(name: String, surname: String) {
        self.name = name
        self.surname = surname
    }
    
    func performance() {
        print("Base method Performance")
    }
}


class Dancer: Artist {
    override func performance() {
        print("\(self.surname) \(self.name). Danace:\u{1F57A}")
    }
}

class Singer: Artist {
    
    override func performance() {
        print("\(self.name) \(self.surname). Sing: \u{1F5E3}")
    }
}


class Painter: Artist {
    override var name: String {
        set {
            22
        }
        
        get {
            return "Leonard"
        }
    }
    
    override var surname: String {
        set {
            
        }
        get {
            return "Black"
        }
    }
    
    
    override func performance() {
        print("\(self.name) \(self.surname). Paint: \u{270D}")
    }
}



let dancer = Dancer(name: "Alex", surname: "White")

let singer = Singer(name: "Robbie", surname: "Williams")

let painter = Painter(name: "Ivan", surname: "Krilov")
painter.surname = "awd"

let artistsArray = [dancer, painter, singer]

for person in artistsArray {
//    if person is Artist {
//        person.performance()
//    }
    person.performance()
    
}





//Task 2
print()

class Vehicle {
    var name = ""
    var speed: Int {
        return 10
    }
    var capacity: Int {
        return 10
    }
    var price: Int {
        return 10
    }
    
    func calcResult() -> (price: Int, time: Double) {
        let distance = 550.0
        
        let totalPrice = capacity * price
        let time = distance / Double(speed)
        
        return (totalPrice, time)
    }
    
    
}


class Airplane: Vehicle {
     static let symbol = "\u{1F6E9}"
    
    override var name: String {
        
        set {
            super.name = newValue
        }
        get {
            return super.name + " \u{1F6E9}"
        }
    }
    
  override  var speed: Int {
        return 250
    }
  override  var capacity: Int {
        return 150
    }
  override  var price: Int {
        return 100
    }
    
}


class Ship: Vehicle {
    
    override var name: String {
        set {
            super.name = newValue
        }
        get {
            return super.name + " \u{1F6F3}"
        }
    }
    
    override  var speed: Int {
          return 80
      }
    override  var capacity: Int {
          return 500
      }
    override  var price: Int {
          return 50
      }
    
}


class Helicopter: Vehicle {
    //static let symbol = "\u{1F681}"
    override var name: String {
        
        set {
            super.name = newValue
        }
        get {
            return super.name + " \u{1F681}"
        }
    }
    
    override  var speed: Int {
          return 150
      }
    override  var capacity: Int {
          return 15
      }
    override  var price: Int {
          return 120
      }
    
}

class Car: Vehicle {
    override var name: String {
        
        set {
            super.name = newValue
        }
        get {
            return super.name + " \u{1F698}"
        }
    }
    
    override  var speed: Int {
          return 110
      }
    override  var capacity: Int {
          return 4
      }
    override  var price: Int {
          return 50
      }
    
}


let car = Car()
car.name = "Car"

let helecopter = Helicopter()
helecopter.name = "Helicopter"

let ship = Ship()
ship.name = "Ship"

let airplane = Airplane()
airplane.name = "Airplane"

let arrayTransport = [car, airplane, ship, helecopter]


func lowAnHight(array: [Vehicle]) {
        
    for vehicle in array {
        
        let (price, time) = vehicle.calcResult()
        print("Transport: \(vehicle.name). Price: \(price). Time: \(time) ")
    
    }
    
}

lowAnHight(array: arrayTransport)





//Task 3

print()



class Animal {
    
}


class Human {
    
   
    
}


class Crocodile: Animal {
    
}

class Dog: Animal {
    

    
}

class Monkey: Animal {
    
}


class Giraffe: Animal {

}


let human_1 = Human()
let human_2 = Human()

let crocodile_1 = Crocodile()
let crocodile_2 = Crocodile()

let dog_1 = Dog()
let dog_2 = Dog()
let dog_3 = Dog()

let monkey_1 = Monkey()
let monkey_2 = Monkey()
let monkey_3 = Monkey()
let monkey_4 = Monkey()

let giraffe_1 = Giraffe()
let giraffe_2 = Giraffe()
let giraffe_3 = Giraffe()

let array: [Any] = [monkey_2, monkey_1, monkey_3, monkey_4, human_1, human_2, dog_1, dog_2, dog_3, giraffe_1, crocodile_2, giraffe_1, giraffe_3, crocodile_1]


let people = array.filter() {$0 is Human}
let reptilies = array.filter() {$0 is Crocodile}
let animals = array.filter(){$0 is Animal}

print("People: \(people.count)")
print("Reptilies: \(reptilies.count)")
print("Animals: \(animals.count)")
