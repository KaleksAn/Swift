import UIKit

let i = -5
let x = +i
print(i)
print(x)
let f = -i
print(f)

var student_1: (name: String?, code: Int?, message: String?)

var student_2 = student_1
student_2.name = "Alex"


let tuple = (2, "D", true)
let (a, y, g) = tuple
print(a)
print(y)
print(g)
print(student_2.name!)
print(type(of: student_2.name!))

let bool = true
var testBool = false
if testBool {
    
} else {
    
}


let r = 3
let u = -r
print(u)
let p = -u
print(p)
let q = u
let e = +u


var var_1 = 2
var var_2 = 3

var var_3 = var_1 > var_2 ? 20 : 40
print(var_3)



for index in 1..<6 {
    print(index)
    print(type(of: index))
}

let names = ["Anna", "Alex", "Bob", "Brian", "Jack"]
let count = names.count
for i in 0..<count {
    print("Person \(i) = \(names[i])")
}


for name in names [2...] {
    print(name)
}



for name in names.reversed() {
    print(name)
}

print("Hello World ")



typealias Kim = Int

var dima: Kim = 0

let doubVar = 2.0

dima = Kim(doubVar)

typealias myString = String

let myPhrase: myString = "Hello!"

typealias NSInteger = Int

let newForm: NSInteger = 234

print(type(of: newForm))



typealias CGFloat = Float
typealias NSDouble = Double
typealias newChar = Character
typealias Empary = UInt


let cgFloat: CGFloat = 222.34
let nsDouble: NSDouble = 2.34
let newCharacter: newChar = "F"
let myNickType: Empary = 34523212323234


let sumResult = cgFloat + Float(nsDouble)


var boolvalue = true

if boolvalue {
    print("This is check!")
} else {
    print("Error check")
}


let day = 3

if day >= 1 && day <= 3 {
    print("YES")
} else {
    print("NO")
}


var nameFirst: String!
var codeForStatus: Int?


var newList = (nameFirst, codeForStatus)

newList.0 = "Rob"
//newList.1 = 25
print(newList.0 ?? "LOL")

if let i = newList.1 {
    print("newMyList = \(i)")
} else {
    print("Optional value have nil")
}


//1
let monthsYear = (January: 31, February: 28, March: 31, April: 30, May: 31, June: 30, Jule: 31, August: 31)

let (January, February, March, April, May, June, Jule, August) = monthsYear

//let allDaysSum = January + February + March + April + May + June + Jule



let secondsOnMinute = 60
let minutesOnHour = 60
let hoursInDay = 24

let infoTime = (secondsOnMinute, minutesOnHour, hoursInDay)
let (seconds, minutes, hours) = infoTime



let dateBirthDay = 9
let differenceDays = monthsYear.August - dateBirthDay


let allSecondsInDay = hoursInDay * secondsOnMinute * minutesOnHour
let allSecondsInYear = allSecondsInDay * 365



let allDaysSumHours = (January + February + March + April + May + June + Jule + differenceDays) * 24

let secondsToMyDay = allSecondsInDay * allDaysSumHours

print("Seconds \(secondsToMyDay) to my birth day ")




//2

let monthMyBirthDay = 3

if monthMyBirthDay >= 1 && monthMyBirthDay <= 3 {
    print("You was born in 1 qurter")
} else if monthMyBirthDay >= 4 && monthMyBirthDay <= 6 {
    print("You was born in 2 quarter")
} else if monthMyBirthDay >= 7 && monthMyBirthDay <= 9 {
    print("You was born in 3 quarter")
} else if monthMyBirthDay >= 10 && monthMyBirthDay <= 12 {
    print("You was born in 4 quarter")
} else {
    print("Enter correctt value")
}





//3
let var01 = 4
let var02 = 10
let var03 = 81
let var04 = 42
let var05 = 63

var resultSum = 0

resultSum = var01 + 2
resultSum = var01 - 2
resultSum = var01 * 5
resultSum = var01 / 3
resultSum = var01 % 3

resultSum = 20

resultSum += var01
resultSum -= var02
resultSum /= var03
resultSum *= var04
resultSum %= var05

print(resultSum)

resultSum = var01 + var02 + var03 + var04 + var05
resultSum = (var05 + var02) * var01 / var04
resultSum = resultSum % var01
resultSum = ((var01 + var05) + var02) * var03


//3


let horizon = 5
let vertical = 6

if horizon % 2 == vertical % 2 {
    print("Black cell")
} else {
    print("White cell")
}



var www = "asdfg"

print(www.reversed())

let hex = 0xFDA1



let testVar = Int("123w")
let varTTest = Int("123w") ?? 0
