//Task 01
//1. Создать структуру “Описание файла” содержащую свойства:
//- путь к файлу
//- имя файла
//- максимальный размер файла на диске
//- путь к папке, содержащей этот файл
//- тип файла (скрытый или нет)
//- содержимое файла (можно просто симулировать контент)
//
//Главная задача - это использовать правильные свойства там, где нужно, чтобы не пришлось хранить одни и те же данные в разных местах и т.д. и т.п.
//



struct File {
    static let maxSize = 5.0
    static let maxSymbolsName = 25
    
    enum Format {
        case docx
        case txt
        case doc
    }
    
    enum StatusHide {
        case yes
        case no
    }
    
    var pathToFile: String
    var nameFile: String {
        didSet {
            if nameFile.count > File.maxSymbolsName {
                print("Maximum symbols for name file equal 25")
                nameFile = oldValue
            }
        }
    }
    var size: Double {
        didSet {
            if size > File.maxSize {
                print("Max size for file 5Gb")
                size = oldValue
            }
        }
    }
    var pathToFolder: String {
        get {
            return pathToFile
        }
        set {
            pathToFile = newValue
        }
    }
    var typeFile: Format
    var hide: StatusHide
    lazy var file = "Text:\"Hello World!\""
}


var file_1 = File(pathToFile: "C/Folder", nameFile: "New_text", size: 2, typeFile: .txt,  hide: .yes)
file_1.pathToFile
file_1.pathToFolder
file_1.file

//2. Создайте энум, который будет представлять некую цветовую гамму.
//Этот энум должен быть типа Int и как raw значение должен иметь соответствующее 3 байтное представление цвета.
//Добавьте в этот энум 3 свойства типа: количество цветов в гамме, начальный цвет и конечный цвет.

enum Colors: Int {
    static var allColors = 3
    static var startColor: Colors {
        return .red
    }
    static var endCoolor = Colors.blue
    
    case red = 0xFF0000
    case green = 0x008000
    case blue = 0x0000FF
}



//3. Создайте класс человек, который будет содержать имя, фамилию, возраст, рост и вес. Добавьте несколько свойств непосредственно этому классу чтобы контролировать:
//- минимальный и максимальный возраст каждого объекта
//- минимальную и максимальную длину имени и фамилии
//- минимально возможный рост и вес
//- самое интересное, создайте свойство, которое будет содержать количество созданных объектов этого класса

class Human {
    static let minAge = 1
    static let maxAge = 110
    
    static let minSizeNameSurname = 1
    static let maxSizeNameSurname = 25
    
    static let minWeight  = 1.50
    static let minHeight = 0.80
    
    static var count = 0

    var name: String {
        didSet {
            if name.count < Human.minSizeNameSurname {
                print("Minimum length for name \(Human.minSizeNameSurname) symbol ")
                name = oldValue
            } else if name.count > Human.maxSizeNameSurname {
                print("Maximum length for name \(Human.maxSizeNameSurname) symbols ")
            }
        }
    }
    
    var surname: String {
        didSet {
            if surname.count < Human.minSizeNameSurname {
                print("Minimum length for surname \(Human.minSizeNameSurname) symbol")
                surname = oldValue
            } else if surname.count > Human.maxSizeNameSurname {
                print("Maximum length ffor \(Human.maxSizeNameSurname) symbols")
                surname = oldValue
            }
        }
    }
    
    var age: Int {
        didSet(oldAge) {
            if age < Human.minAge {
                print("Minimum age for  human \(Human.minAge)")
                age = oldAge
            } else if age > Human.maxAge {
                print("Maximum age for human \(Human.maxAge)")
                age = oldAge
            }
        }
    }
    
    var height: Double {
        didSet {
            if height < Human.minHeight {
                print("Minimum weight for human \(Human.minHeight)")
                height = oldValue
            }
        }
    }
    
    var weight: Double {
        didSet(oldWeight) {
            if weight < Human.minWeight {
                weight = oldWeight
            }
        }
    }
    
    init(name: String, surname: String, age: Int, height: Double, weight: Double) {
        self.name = name
        self.surname = surname
        self.age = age
        self.height = height
        self.weight = weight
        
        Human.count += 1
    }
}


let person_1 = Human(name: "Alan", surname: "Rick", age: 1, height: 75.0, weight: 179.1)
let person_2 = Human(name: "Greg", surname: "Johnson", age: 22, height: 168.5, weight: 62.4)
Human.count



