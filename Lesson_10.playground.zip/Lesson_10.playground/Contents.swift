//Lesson_10
//Functions

import Foundation


func greet(person: String) -> String {
    let greeting = "Hello, " + person
    return greeting
}

print(greet(person: "Anna"))
print(greet(person: "Brian"))



func greetAgain(person: String) -> String {
    return "Hello again, " + person + "!"
}

print(greetAgain(person: "Fred"))



//Function without parameter's

func sayHelloWorld() -> String {
    return "Hello, World!"
}

print(sayHelloWorld())


func giveMeNumber() -> Int {
    let random = Int.random(in: 0...100)
    return random
}

print("Random number from function \(giveMeNumber())")



//Function with parameter's

func greet(person: String, alreadyGreeted: Bool) -> String {
    if alreadyGreeted {
        return greetAgain(person: person)
    } else {
        return greet(person: person)
    }
}

print(greet(person: "Tim", alreadyGreeted: true))


//------
func sayBye(person: String) -> String {
    return "Bye, \(person)"
}

func sayPhrase(person: String) -> String {
    return "\(person), finished work!"
}


func pairVariant(name: String, status: Bool) -> String {
    if status {
        return sayBye(person: name)
    } else {
        return sayPhrase(person: name)
    }
}


print(pairVariant(name: "Dima", status: false))


//Function's without return value's

func greet1(person: String) {
    print("Hello, \(person) !")
}

greet1(person: "Dave")


func printAndCount(string: String) -> Int {
    print(string)
    return string.count
}

func printWithoutCouting(string: String) {
    let _ = printAndCount(string: string)
}

printAndCount(string: "Hello, world!")
printWithoutCouting(string: "Hello, world!")


//Функции, возвращающие несколько значений

func minMax(array: [Int]) -> (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
          currentMax = value
        }
    }
    return (currentMin, currentMax)
}

let cash = [1000, 12, 34, 200, 2, 43]

minMax(array: cash)

let (minimum, maximum) = minMax(array: cash)
print(maximum)
print(minimum)


let bounds = minMax(array: [2, 3, -23, 22, 54])
print("Test function \(bounds.min)")
print("Test function \(bounds.max)")


//Опциональный кортеж как возвращаемый тип

func minMaxOpt(array: [Int]) -> (min: Int, max: Int)? {
    if array.isEmpty { return nil}
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}


if let bounds = minMaxOpt(array: [Int]()) {
    print("Min is \(bounds.min) and max is \(bounds.max)")
}

type(of: bounds.max)
type(of: bounds.min)


//Ярлыки аргументов и имена параметров функций

func someFunction(firstParameterName: Int, secondParameetrName: Int) {
    
}

someFunction(firstParameterName: 1, secondParameetrName: 2)



func someFunction2(argumentLabel paramettrName: Int) {
    
}

someFunction2(argumentLabel: 223)


func greet(person: String, from hometown: String) -> String {
    return "Hello \(person)! Glad you could visit from \(hometown)"
}

print(greet(person: "Bill", from: "Cupertino"))



func someFunction3(_ firstParameterName: Int, secondParameterName: Int) {
    
}

someFunction3(1, secondParameterName: 2)



// Значения по умолчанию для параметров

func somefunction4(parameterWithoutDefault: Int, parameterWithDefault: Int = 12) {
    
}

somefunction4(parameterWithoutDefault: 6)
somefunction4(parameterWithoutDefault: 3, parameterWithDefault: 6)



//Вариативные параметры

func arithmeticMean(_ numbers: Double...) -> Double {
    var total: Double = 0
    for number in numbers {
        total += number
    }
    return total / Double(numbers.count)
}


arithmeticMean(1, 2, 4, 5, 12)

let a: Double = 23
let b: Double = 99
let c: Double = 32

arithmeticMean(a, b, c)

//Функция может иметь только один вариативный параметр
func arithmeticMean2(_ num: Int..., num2: Int) -> Int {
    var sum = Int()
    for i in num {
        sum = i + num2
    }
    return sum
}



//Сквозные параметры



func swapTwoInts(_ a: inout Int, _ b: inout Int) {
    let temroryA = a
    a = b
    b = temroryA
}


var someInt = 3
var anotherInt = 107

swapTwoInts(&someInt, &anotherInt)

print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")





func swapOneInts(_ a: inout Int, _ b: Int) -> String {
    a += b
    return "Task finished!"
}


var myVal = 10
let myVal02 = 6
swapOneInts(&myVal, myVal02)

print("My val = \(myVal)")



func pairString(str1: inout String, str2: String) -> String {
    str1 = str2
    return str1
}

var str1 = "Hello"
let str2 = "Privet"

pairString(str1: &str1, str2: str2)

print(str1)





//Функциональные типы

//Тип даных функций (Int, Int) -> Int
func addTwoInts(a: Int, _ b: Int) -> Int {
    return a + b
}

func multyplyTwoInts(a: Int, _ b: Int) -> Int {
    return a * b
}

//Тип функции без параметров () -> void
func printHelloWorld() {
    print("Hello World!")
}




//Использование функциональных типов
//Тип функции можно явно присвоить переменной
var mathFunction: (Int, Int) -> Int = addTwoInts

//Вызов функции через переменную
print("Result: \(mathFunction(2, 3))")

//Присвоение переменной аналогичной функции
mathFunction = multyplyTwoInts

print("Result multyply: \(mathFunction(9, 9))")

//Тип функции присваивается автоматически
let anotherMathFunction = addTwoInts
let anotherMathFunction_02 = multyplyTwoInts(a: 3, 8)



//Функциональные типы как типы параметров

func printMathResult(_ mathFunction: (Int, Int) -> Int, _ a: Int, _ b: Int) {
    print("Result: \(mathFunction(a, b))")
}

printMathResult(addTwoInts, 3, 5)
printMathResult(multyplyTwoInts, 5, 7)

//Функциональные типы как возвращаемые типы
func stepForward(_ input: Int) -> Int {
    return input + 1
}


func stepBackward(_ input: Int) -> Int {
    return input - 1
}

//Тип функции в качестве возвращаемого значения функции

func chooseStepFunction(backward: Bool) -> (Int) -> Int {
    return backward ? stepBackward : stepBackward
}


var currentValue = 3
let moveNearerToZero = chooseStepFunction(backward: currentValue > 0)


print("Counting to zero:")
while currentValue != 0 {
    print("\(currentValue)...")
    currentValue = moveNearerToZero(currentValue)
}
print("zero")

let myTest = chooseStepFunction(backward: currentValue < 0)
myTest(8)


func returnFunc(var1: Int, var2: Int) -> (Int) -> Int {
    return var1 > var2 ? stepForward : stepBackward
}



let date1 = 19972
let date2 = 2001

let myTest2 = returnFunc(var1: date1, var2: date2)

myTest2(343)



//Вложенные функции

func chooseStepFunction2(backward: Bool) -> (Int) -> Int {
    func stepForward2(input: Int) -> Int {return input + 1}
    func stepBackward2(input: Int) -> Int {return input - 1}
    return backward ? stepBackward2 : stepForward2
}

var currentValue2 = -4
let moveNearerToZero2 = chooseStepFunction2(backward: currentValue2 > 0)

while currentValue2 != 0 {
    print("\(currentValue2)...")
    currentValue2 = moveNearerToZero2(currentValue2)
}
print("zero")



func myTestFunc(enterStatus status: Bool) -> (String) -> String {
    func helloMan(name: String) -> String {
        return "Hello, \(name)"
    }
    
    func byeMan(name: String) -> String {
        return "Bye, \(name)"
    }
    
    return status ? helloMan : byeMan
    
}


myTestFunc(enterStatus: true)("Ivan")

let referenceFunc = myTestFunc(enterStatus: true)

referenceFunc("Dima")



func codeString(code: Int, message: String) -> String {
    var mutableMessage = message
    mutableMessage += String(code)
    return mutableMessage
}

codeString(code: 404, message: "Page not found error ")
let message = codeString(code: 404, message: "Page not found error ")

print("Server answer: \(message)")




func printRequestString(codes: Int...) -> () {
    var codesString = ""
    for oneCode in codes {
        codesString += String(oneCode) + " "
        print(oneCode)
    }
    print("Получены ответы - \(codesString)")
}

printRequestString(codes: 200, 3, 4)




//Sample

func getCodeDescripttion(code: Int) -> (code: Int, description: String) {
    let description: String
    switch code {
        case 1...10:
            description = "Error"
        case 101...200:
            description = "Correct"
        default:
            description = "Unknown"
    }
    return (code, description)
    
}



getCodeDescripttion(code: 105)
let answer = getCodeDescripttion(code: 202)

answer.code



//Default value

func returnMessage (code: Int, message: String = "Code - ") -> String {
    var mutableMessage = message
    mutableMessage += String(code)
    return mutableMessage
}

returnMessage(code: 300)
returnMessage(code: 300, message: "Status ")




//Function in function

func printText() {
    print("Функция ввызвана!")
}

func returnPrintTextFunction() -> () -> () {
    return printText
}

print("Step 1")
let newFunctionInlet = returnPrintTextFunction()
print("Step 2")
newFunctionInlet()
print("Step 3")





//Input function type

func generateWallet(walletLenght: Int) -> [Int] {
    let typesofBanknotes = [50, 100, 500, 1000, 5000]
    var wallet: [Int] = []
    for _ in 1...walletLenght {
        wallet.append(typesofBanknotes.randomElement()!)
    }
    return wallet
}


func sumWallet(banknotsFunction wallet: (Int) -> [Int], walletLength: Int) -> Int? {
    let myWalletArray = wallet(walletLength)
    var sum: Int = 0
    for oneBanknote in myWalletArray {
        sum += oneBanknote
    }
    
    return sum
}

sumWallet(banknotsFunction: generateWallet, walletLength: 20)




//Вложенные функции

func oneStep(coordinates: inout (Int, Int), stepType: String) {
    func up (coords: inout (Int, Int)) {
        coords = (coords.0 + 1, coords.1)
    }
    
    func right(coords: inout (Int, Int)) {
        coords = (coords.0, coords.1 + 1)
    }
    
    func down(coords: inout (Int, Int)) {
        coords = (coords.0 - 1, coords.1)
    }
    
    func left(coords: inout (Int, Int)) {
        coords = (coords.0, coords.1 - 1)
    }
    
    
    switch stepType {
        case "up":
            up(coords: &coordinates)
        case "right":
            right(coords: &coordinates)
        case "down":
            down(coords: &coordinates)
        case "left":
            left(coords: &coordinates)
        default:
            break
    }
}


var coordinates = (10, -5)

oneStep(coordinates: &coordinates, stepType: "up")
oneStep(coordinates: &coordinates, stepType: "right")

print("Coordinates = \(coordinates)")

coordinates.0
coordinates.1



//Рекурсия

func countdown(firstNum num: Int) -> Void {
    print(num)
    if num > 0 {
        countdown(firstNum: num - 1)
    }
}

countdown(firstNum: 20)
