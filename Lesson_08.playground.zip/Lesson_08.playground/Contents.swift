//Dictionary

//Create empty dictionary
let dictEmpty1 = Dictionary<String, Int>()
let dictEmpty2: [Int: String] = [:]
let dictEmpty3: Dictionary<Int, String> = [:]
let dictEmpty4 = [String: Int]()


var usersAndId = ["Alex": 12342, "Kim": 666234]
let arrayKeys = usersAndId.keys.sorted()
let arrayValues = usersAndId.values.sorted()
type(of: arrayKeys)
type(of: arrayValues)


usersAndId["Ferz"] = 6132401

usersAndId
usersAndId.count
usersAndId.isEmpty
usersAndId.removeAll()
usersAndId.isEmpty



type(of: usersAndId["Ferz"])




//func canThrowAnError() throws {
//    //Эта функция может сгенерировать ошибку
//}
//
//
//
//do {
//    try canThrowAnError()
//    //Ошибка не была сгенерирована
//} catch {
//    //Ошибка сгенерирована
//}


var namesOfIntegers = [Int: String]()

namesOfIntegers[16] = "sixteen" //Если данный ключ и значение отсутствуют, то добавляются новые значения

namesOfIntegers = [:]


//var airports: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]//Пример из документации

var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin", "TAS": "Taskent", "INCH": "Incheon"]


if airports.isEmpty {
    print("Dictionary \"Airports\" is empty!")
} else {
    print("Dictionary is not empty")
}

airports["MSK"] = "Moskov"

print("values dictionary \(airports.values)")
print("Keys from dictionary \(airports.keys)")


type(of: airports.keys)



//Arrays for values and keys
let newArrayKeys = [String](airports.keys)
let newArrayValues = [airports.values]



type(of: newArrayKeys)
type(of: newArrayValues)

let baseCollecttion = [(2, 5), (3, 6), (1, 4)]
let newDicttionary = Dictionary(uniqueKeysWithValues: baseCollecttion)
let newDictionary1 = Dictionary(dictionaryLiteral: ("Vasya", 2), ("Petya", 0))

print(newDicttionary)

print("Name: \(newDictionary1["Vasya"]!)")


//Array star's

let nearestStarNames = ["Proxima Centauri", "Alpha Centauri A", "Alpha Centauri B", "Zevs"]
//Array distance to star's
let nearesStarDistances = [4.24, 4.37, 4.37, nil]

//Create dictionary from two array
//Get array, have pair value
let starDistanceDict = Dictionary(uniqueKeysWithValues: zip(nearestStarNames, nearesStarDistances))

print("Star dictionary \(starDistanceDict)")


for i in starDistanceDict.values {
    
    if let value = i {
        print("Values in dictionary:  key: \(value) ")

    } else {
        print("value nil")
    }
    
}


//Data type

let codeDesc = [200: "success",300: "warning", 400: "error"]
type(of: codeDesc)



//Use elements from dictionary

var countryDict = ["RUS": "Россия", "BEL": "Белоруссия", "UKR": "Украина", "KOR": "Южная Корея"]
//Get element
var countryName = countryDict["UKR"]
print("Country name: \(countryName!)")

//Edit value element

countryDict["RUS"] = "Российская Федерация"


print("Country dictionary: \(countryDict)")


var oldValueOne = countryDict.updateValue("Republic of Belarus", forKey: "BEL")
print("Old value: \(oldValueOne!)")

//Edit fake value
var oldValueTwo = countryDict.updateValue("Эстония", forKey: "EST")
print("Old value two: \(oldValueTwo)")


//Add new element on dictionary
countryDict["UZB"] = "Republic of Uzbekistan"
countryDict["KAZ"] = "Republic of Kazahstan"

print("New element's in dictionary: \(countryDict)")

//Delete value on dictionary

countryDict["UKR"]  = nil
countryDict.removeValue(forKey: "KOR")
print("Country dictionary: \(countryDict)")


//Empty dictionary

let emptyDictionary: [String: Int] = [:]
let anotherEmptyDictionary = Dictionary<Int, String>()

//Delete all values in dictionary

var birthYears = [1991: ["John", "Ann", "Vasiliy"], 1993: ["Alex", "Boris", "John"]]
birthYears = [:]
print("Empty dictionary: \(birthYears)")

//Base property and motthod's is dictionary
var someDictionary = ["One": 1, "Two": 2, "Three": 3]
someDictionary.count
someDictionary.isEmpty

//Get all keys and values

//All keys from countryDict
let keys = countryDict.keys
type(of:keys)
print("All keys \(keys)")

let values = countryDict.values

type(of: values)
print("All values from countryDict \(values)")


//Преобразование значение ключей и значений в другие коллекции

let keysSet = Set(keys) //Set
let keysSet2 = Set(values)
type(of: keysSet)
let keysSet3 = Set<String>(keys)




let valuesArray = Array(values) //Array
type(of: valuesArray)
let valuesArray2 = Array<String>(values)
type(of: valuesArray2)

let valuesArray3 = [values]

type(of: valuesArray3)


let valuesArray4 = Array(values)

print(valuesArray2)


//var emptDict = [Int: String]()
//var emptDict2: [String: Int] = [:]





//The Swift Developers group
//Homework

//1
//Cоздать 10 разных Dictionary с разными типами данных.Один из них должен содержать все месяца года на русском.Второй на английском.

let monthsAndDays1 = ["January" : 31,
                    "February": 28,
                    "March": 31,
                    "April": 30,
                    "May": 31,
                    "June": 30,
                    "Jule": 31,
                    "August": 31,
                    "September": 30,
                    "October": 31,
                    "November": 30,
                    "December": 31]

let monthsAndDays2: [String: Int] = ["Январь": 31,
                                     "Февраль": 28,
                                     "Март": 31,
                                     "Арпель": 30,
                                     "Май": 31,
                                     "Июнь": 30,
                                     "Июль": 31,
                                     "Август": 31,
                                     "Сентябрь": 30,
                                     "Октябрь": 31,
                                     "Ноябрь": 30,
                                     "Декабрь": 31]


var carDictionary = ["BMW": 5347, "AUDI": 7777, "LEXUS": 0002, "FORD": 3402]
var phoneBook = ["Alex": 998903342756, "Dima Kim": 79802134566, "Tony Stark": 010826485]
var filmsFees = ["Lion king": 1000500, "Terminator 6": 2_500_000, "The Rock": 4000_000]
var productsAndPrice = ["Banana": 3, "Iphone 12 PRO": 1500, "Meat": 10]
//var studentsRating = ["Kim Dmitriy": 5, "Pak Andrey": 4, "Kan Roman": 3]
var idAndNumber = [999: "AO2354", 43623: "AA66753", 91342: "FF13513"]

var emptyDictionary1 = [String: Int]()
var emptyDictionary2: Dictionary<String, Int> = [:]

//Array for dictionary
let name = ["Bob Dylan", "Black Jack", "Mike Tyson", "Michel Jordan"]
let dateBorn = [1965, 1966, 1965, 1968]


//1.1
for i in monthsAndDays1.keys {
    if let value = monthsAndDays1[i] {
    print("Month \(i) have \(value) days")
    }
}


for i in monthsAndDays2.keys {
    if let value = monthsAndDays2[i] {
        print("Месяц \(i) имеет \(value)  дней")
    }
}




//1.2

if emptyDictionary1.isEmpty {
    emptyDictionary1 = Dictionary(uniqueKeysWithValues: zip(name, dateBorn))
} else {
    print("Dictionary have value!")
}





for i in emptyDictionary1.keys {
    if let date = emptyDictionary1[i] {
        print("Name \(i) - \(date) ")
    }
    
}


if emptyDictionary1.isEmpty {
    print("Dictionary is empty!")
} else if !emptyDictionary1.isEmpty {
    for key in phoneBook.keys {
        emptyDictionary1[key] = phoneBook[key]
        print("Name \(key) and \(emptyDictionary1[key] ?? 0) ")
    }
}

for (key, value) in emptyDictionary1.enumerated() {
    print("Key \(key) Value \(value)")
}



//.let monthsAndDay = (monthsAndDays1.keys, monthsAndDays1.values)

for (key, value) in monthsAndDays1 {
    print("Months \(key) days \(value)")
}




//Alexey Skutarenko
//Task 1

var studentRating = ["Kim Dmitriy": 5, "Pak Andrey": 4, "Kan Roman": 4]
print("Stock dictionary \(studentRating)")
//Refresh data
studentRating["Pak Andrey"] = 5
studentRating.updateValue(5, forKey: "Kan Roman")
print("Dictionary student \(studentRating)")

//Add new student's
studentRating.updateValue(4, forKey: "Li Mihail")
studentRating["Li Vladimir"] = 5
print("New student's in dictionary \(studentRating)")

//Delete and appeend student's
studentRating["Kim Dmitriy"] = nil
studentRating["Ogay Sergey"] = 4
studentRating.removeValue(forKey: "Li Mihail")
print("Dictionary \(studentRating)")


//1.1
var scoreGroup = 0
var averageScore = 0.0
var count = 0

for value in studentRating.values {
    count += 1
    scoreGroup += value
    if count == studentRating.count {
        averageScore = Double(scoreGroup / studentRating.count)
        print("Score group \(scoreGroup)")
        print("Average score grouup \(averageScore)")
    }
}


//Task 2
/*
 Создать дикшинари дни в месяцах, где месяц это ключ, а количество дней - значение. В цикле выведите ключ-значение попарно, причем один раз выведите через тюплы, а другой раз пройдитесь по массиву ключей и для каждого из них доставайте значения.
 */

//Use tuple's
for (month, days) in monthsAndDays1 {
    print("Name month: \(month); Days: \(days);")
}

//Use array keys
for key in monthsAndDays1.keys {
    print("Month key: \(key) and days value: \(monthsAndDays1[key] ?? 0)")
}


//Task 3
/*
 Создать дикшинари , в которой ключ это адрес шахматной клетки (пример: a5, b3, g8), а значение это Bool. Если у клетки белый цвет, то значение true, а если черный - false. Выведите дикшинари в печать и убедитесь что все правильно.
Рекомендация: постарайтесь все сделать используя вложенный цикл (объяснение в уроке)
 */

//My variant
var cellAdress  = [String: Bool]()
var blacOrWhite: Bool
let numbers = Array(1...8)
let letters = ["A", "B", "C", "D", "E", "F", "G", "H"]
var cell = 0

for number in numbers {
    
    for (index, letter) in letters.enumerated() {
        
//cell = index + 1
//cell % 2
        if number % 2 == (index + 1) % 2 {
            blacOrWhite = false
            cellAdress.updateValue(blacOrWhite, forKey: "\(letter), \(number)")
        } else {
            blacOrWhite = true
            cellAdress.updateValue(blacOrWhite, forKey: "\(letter), \(number)")
        }
        
        print("Cell \(letter), \(number): value \(cellAdress["\(letter), \(number)"]!) ")
    }
}


//Variant's other user's


var emptyCellDict = [String: Bool]()
let cellLetters = ["A", "B", "C", "D", "E", "F", "G", "H"]

for i in 0..<cellLetters.count {
    for y in 1...8 {
        emptyCellDict["\(cellLetters[i]) \(y)"] = y % 2 != 0 ? true : false
    }
}

for (key, value) in emptyCellDict {
    print("Empty dictionary have: key \(key), value \(value)")
}


// Alexey Skutarenko method

var cellAdress2 = [String: Bool]()
var blackOrWhite2: Bool
let numbersArray = Array(1...8)
let lettersArray = ["A", "B", "C", "D", "E", "F", "G", "H"]
//let lettersArray = Array("A"..."Z")
var cell2 = 0

for num in numbersArray {
    
    for (index, letter) in lettersArray.enumerated() {
        cell2 = index + 1
        
        blackOrWhite2 = (num % 2 != cell2 % 2)
        cellAdress2.updateValue(blackOrWhite2, forKey: "\(letter), \(num)")
        print("Alex Skutarenko method: \(String(describing: cellAdress2["\(letter), \(num)"]!)), Value cell: \(letter), \(num)")
    }
    
}



//Create array letter's
let aScalars = "A".unicodeScalars
let aCode = aScalars[aScalars.startIndex].value

let letters4: [Character] = (0..<26).map {
    i in Character(UnicodeScalar(aCode + i)!) 
}




for i in letters4 {
    print("i = \(i)")
}






cellAdress["B, 4"]


cellAdress.removeAll()


//Test with letter's
let lettresTest = Array(letters)
for i in lettresTest {
    print("My new test with letter's \(i)")
}



