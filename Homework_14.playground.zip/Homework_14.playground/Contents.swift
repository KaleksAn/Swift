import Foundation

//1. Самостоятельно повторить проделанное в уроке
//2. Добавить студенту property «Дата рождения» (пусть это будет еще одна структура, содержащая день, месяц, год) и два computed property: первое — вычисляющее его возраст, второе — вычисляющее, сколько лет он учился (считать, что он учился в школе с 6 лет, если студенту меньше 6 лет — возвращать 0)

struct DateBirth {
    var day = 1 {
        didSet {
            if day > 31 {
                day = oldValue
            }
        }
    }
    
    var month = 1 {
        didSet {
            if month < 0 && month > 12 {
                month = oldValue
            }
        }
    }
    
    var year = 1 {
        didSet {
            if year < 0 {
                year = oldValue
            }
        }
    }
    
    var age: Int {
        
        set {
            year = Calendar.current.component(.year, from: Date()) - newValue
        }
        
        get {
            return Calendar.current.component(.year, from: Date()) - year
        }
        
    }
    
    var timeStudy: Int {
        get {
            if age < 6 {
                return 0
            } else if age >= 6 && age <= 17 {
                
                var count = 0
                for i in 7...age {
                    count += 1
                    if i == age {
                        return count
                    }
                    
                }
            } else if age > 17 {
                return 11
            }
            return 0
        }
    }
    
}


struct Student {
    var name: String {
        didSet {
            name = name.localizedCapitalized
        }
    }
    
    var surname: String {
        didSet {
            surname = surname.localizedCapitalized
        }
    }
    
    var fullName: String {
        set {
            let arrayForName = newValue.components(separatedBy: " ")
            if arrayForName.count > 0 {
                name = arrayForName[0]
            }
            if arrayForName.count > 1 {
                surname = arrayForName[1]
            }
            
        }
        
        get {
            return name + " " + surname
        }
    }
    
    
    var dateBirth = DateBirth()
    
}


var stud_Test = Student(name: "Dima", surname: "Kim", dateBirth: DateBirth(day: 9, month: 8, year: 2009))

stud_Test.dateBirth.age
stud_Test.dateBirth.timeStudy
stud_Test.dateBirth.age = 30
stud_Test.dateBirth.year
stud_Test.dateBirth.age
stud_Test.fullName

/*
var arrayNames = [String]()
class People {
    var name: String {
        didSet {
            name = name.localizedCapitalized
            arrayNames.append(oldValue)
        }
    }
    var secondname: String {
        didSet {
            secondname = secondname.localizedCapitalized
        }
    }
    
    var age: Int
    
    init(_ name: String, _ secondname: String, _ age: Int) {
        self.name = name
        self.secondname = secondname
        self.age = age
    }
    
    init() {
        self.name = "Default"
        self.secondname = "Default"
        self.age = 0
    }
}


let man_1 = People("Alex", "Chen", 22)
man_1.name = "Victor"
man_1.name = "Tony"

let man_2 = People("Dima", "Li", 11)
man_2.name = "Igor"
man_2.name = "Fred"

let man_3 = People()
man_3.name
*/




//3. Создать структуру «Отрезок», содержащую две внутренние структуры «Точки».
//Структуру «Точка» создать самостоятельно, несмотря на уже имеющуюся в Swift’е.
//Таким образом, структура «Отрезок» содержит две структуры «Точки» — точки A и B (stored properties).
//Добавить два computed properties: « середина отрезка» и «длина» (считать математическими функциями)


// Var 1
struct Segment {
    
    var A: Double
    var B: Double
    
    var middlePoint: Double {
        get {
            return (A + B) / 2
        }
    }
    
    var lenght: Double {
        get {
            return A + B
        }
    }
    
    
}

var segment_1 = Segment(A: 2, B: 5)
segment_1.middlePoint
segment_1.lenght





//Var 2

struct Segment_2 {
    struct Point {
        var pointX: Double
        var pointY: Double
    }
    
    var A: Point
    var B: Point
    
    var midPoint: Point {
        get {
            let pointA = (A.pointX + B.pointX) / 2
            let pointB = (A.pointY + B.pointY) / 2
            return Point(pointX: pointA, pointY: pointB)
        }
        
        set {
            let differentX = newValue.pointX - midPoint.pointX
            let differntY = newValue.pointY - midPoint.pointY
            
            A.pointX += differentX
            A.pointY += differntY
            
            B.pointX += differentX
            B.pointY += differntY
            
        }
    }
    
    var length: Double {
        get {
           
            return sqrt(((B.pointX - A.pointX) * (B.pointX - A.pointX)) + ((B.pointY - A.pointY) * (B.pointY - A.pointY)))
        }
        
        set {
            B.pointX = (A.pointX + (B.pointX - A.pointX) * newValue / length)
            B.pointY = (A.pointY + (B.pointY - A.pointY) * newValue / length)
        }
        
    }
}



//4. При изменении середины отрезка должно меняться положение точек A и B. При изменении длины, меняется положение точки B


var segment_01 = Segment_2(A: .init(pointX: 5, pointY: 5), B: .init(pointX: 10, pointY: 15))

print(segment_01.midPoint)
print(segment_01.midPoint)
segment_01.midPoint = .init(pointX: 2, pointY: 2)
print(segment_01.midPoint)

segment_01.length
segment_01.length = 222
print(segment_01.length)
segment_01.B
print(segment_01.B)
print(segment_01.midPoint)

let test = pow(2, 3)
