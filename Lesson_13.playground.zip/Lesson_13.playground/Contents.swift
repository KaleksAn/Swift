//Classe's and structure

class StudentClass {
    
    var name: String
    var age: Int
    
    init() {
        name = "No name"
        age = 20
    }
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
}


struct StudentStruct {
    var name: String
    var age: Int
}




let stClass1 = StudentClass(name: "Bob", age: 18)
stClass1

stClass1.name = "Alex"
stClass1.age = 21


func addOneYear(student: StudentClass) {
    student.age += 1
}

func addOneYear(student: StudentStruct) {
    _ = student.age + 1
}

var stStruct1 = StudentStruct(name: "Sam", age: 24)

stStruct1

var stStruct2 = stStruct1
stStruct2.age = 25
stStruct2.name = "Samuel"

stStruct2
stStruct1

var stClass2 = stClass1
stClass2.age = 20
stClass2.name = "AAA"

stClass2
stClass1


stStruct1
addOneYear(student: stStruct1)



//Создание классов и структур
class SomeeClass {
    
}

struct SomeStructure {
    
}



struct Resolution {
    var width = 0
    var height = 0
}


class VideoMode {
    var resolution = Resolution()
    var interlaced = false
    var frameRate = 0.0
    var name: String?
}

//Экземпляры класса и структуры
let someResolution = Resolution()
let someVidoeMode = VideoMode()


//Доступ к свойствам

print("The width of someResolution is \(someResolution.width)")
print("The width of someVideoMode is \(someVidoeMode.resolution.width)")

//Присваивание нового значения для свойства
someVidoeMode.resolution.width = 1280
print("The width of someVideoMode is now \(someVidoeMode.resolution.width)")


//Поэлементные инициализаторы структурных типов
//Другими словами - присвоение новых значений свойств для создаваемого объекта структуры
let vga = Resolution(width: 640, height: 480)



//Структуры и перечисления - типы значения
//Структуры и перечисления имеют тип Value Type
let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
cinema.width = 2048

print("Cinema is now \(cinema.width) pixels wide")
print("Hd is still \(hd.width) pixels wide")


//Enum's
enum CompassPoint {
    case north, south, east, west
    mutating func turnNorth() {
        self = .north
    }
}


var currentDirection = CompassPoint.west
let rememberedDirection = currentDirection
currentDirection.turnNorth()

print("Текущее направление = \(currentDirection)")
print(rememberedDirection)


//Классы - ссылочный тип
//Классы имеют значение reference type (ссылочный)

let tenEighty = VideoMode()

tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0

print("The frameRate property of tenEighty is now \(tenEighty.frameRate)")



//Операторы тождественности или сравнения
//===   !===
//Используют для проверки того, ссылаются ли две константы или переменные на один и тот же экземпляр класса
//Используются только для сравнения экземпляров класса
let sixMod = VideoMode()

if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
}


if alsoTenEighty !== sixMod {
    print("True!")
} else {
    print("False!")
}


let newResolution = Resolution(width: 1020, height: 4040)
let secondResolution = Resolution(width: 23, height: 32)

//if newResolution === secondResolution {
//    print("True struct")
//} else {
//    print("False struct")
//}




struct PropertyPhone {
    var screen = (320, 240)
    var size = 16
    var weight = 100
}


var phone = PropertyPhone()

phone.size = 23
phone.screen = (440, 550)
phone.weight = 250


class CarProperty {
    var nameCar: String
    var speedMaxCar: Int
    var maxFuel: Int
    
    init(name: String, speed: Int, fuel: Int) {
        self.nameCar = name
        self.speedMaxCar = speed
        self.maxFuel = fuel
    }
}


let kia = CarProperty(name: "KIA", speed: 220 , fuel: 50)

kia.nameCar = "KIA SORENTO"
kia.speedMaxCar = 330
kia.maxFuel = 60


print("Kia model: \(kia.nameCar)")




//Василий Усов
//Структуры

struct PlayerInChess {
    var name: String
    var wins: UInt
}

//var oleg = PlayerInChess(name: <#T##String#>, wins: <#T##UInt#>)
//type(of: oleg)


var harry = PlayerInChess(name: "Harry", wins: 32) //Экземпляр структуры со свойствами

//Значения свойств по умолчанию
struct PlayerInChessNew {
    var name = "Player" // Значения по умолчанию
    var wins: UInt = 0
}

var john = PlayerInChessNew(name: "John", wins: 32)
var player = PlayerInChessNew() //Пустой инициализатор


//Стркуктура как пространство имён
//Доступ к элементам структуры через её экземпляры

john.name
player.name

john.wins
john.wins += 1
john.wins

//Если свойство или экземпляр указаны как константа, то изменение свойства невозможно

let alex = PlayerInChess(name: "Alex", wins: 88)

alex.name
alex.wins
//alex.wins += 1 <- Error!


//При создании структуры автоматоматически создаётся инициализатор для свойств!
//Если свойствам заданы значения по умолчанию, то доступен пустой инициализатор
//Инициализатор init - это специальный метод


//Собственные инициализаторы
//При создании собственного инициализатора, авотматически созданные встроенные инициализаторы удаляются
//Если создать новый инициализатор только для одного свойства, то остальные свойства должны иметь значения по умолчанию.

struct PlayerOnChess {
    var name = "Player"
    var wins: UInt = 0
    //инициализатор
    init(name: String) {
        self.name = name
    }
}

var helga = PlayerOnChess(name: "Olga")
helga.wins

//var newPlayer = PlayerOnChess() <- Error


//Структуры имеют тип Value type
var olegMuhin = PlayerOnChess(name: "Oleg")
var olegLapin = olegMuhin

olegMuhin.name = "Oleshka"

print("\(olegMuhin.name), \(olegLapin.name)")



//Методы в структурах
//Для доступа к собственным свойствам структуры используется оператор self


struct PlayerChess {
    var name = "Player"
    var wins: UInt = 0
    
    init(name: String) {
        self.name = name
    }
    
    func description() {
        print("Player \(self.name) have \(self.wins) winner's")
    }
    
}


var andrey = PlayerChess(name: "Andrey")
andrey.description()

//Изменяющие методы
//По умолчанию методы структур не могут изменять значения свойств
//Для обхода данного ограничения, перед именем объявляемого метода указывается модификатор mutating

struct GamerInChess {
    
    var name = "Player"
    var wins: UInt = 0
    
    init(name: String) {
        self.name = name
    }
    
    func description() {
        print("Player \(self.name) have \(self.wins) winner's")
    }
    
    mutating func win(count: UInt = 1) {
        self.wins += count
    }
    
}


var harold = GamerInChess(name: "Harold")
harold.wins
harold.win()
harold.wins
harold.win(count: 3)
harold.wins




//Классы

//Создание
class Player {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
    
}

//Свойства классов
//Класс имеет пустой инициализатор
//Для присвоения нового значения свойству объекта нужно создавать свой инициализатор
class Chessman {
    let type: String
    let color: String
    var coordinates: (String, Int)?
    let figureSymbol: Character
    
    init(type: String, color: String, figure: Character) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
    }
    
}

//Экземпляр класса

var kingWhite = Chessman(type: "King", color: "White", figure: "\u{2654}")

//Свойства type и color могут принять значения из четко определённого перечня, поэтому реализуем два перечисления
//Тип и  цвет


enum ChessmanType {
    case king, castle, bishop, pawn, knight, queen
}

enum ChessmanColor {
    case black, white
}


//Новый класс инициализируемый типом перечисления
//Методы классов


//В классах не используется модификатор mutating для методов, меняющих значения свойств


class ChessmanNew {
    let type: ChessmanType
    let color: ChessmanColor
    var coordinates: (String, Int)?
    let figureSymbol: Character
    
    init(type: ChessmanType, color: ChessmanColor, figure:Character) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
    }
    //Метод установки координат
    func setCoordinates(char c: String, num n: Int) {
        self.coordinates = (c, n)
    }
    
    //Метод убивающий фигуру
    func kill() {
        self.coordinates = nil
    }
    
}

var knightWhiteNew = ChessmanNew(type: .knight, color: .white, figure: "\u{2654}")


var kingBlack = ChessmanNew(type: .king, color: .black, figure: "\u{2654}")
kingBlack.setCoordinates(char: "E", num: 1)


//Инициализаторы классов
//Класс может содержать произвольное количество инциализаторов
//В инициализатор можно передавать аргументы для функций во избежание дублирования кода


class ChessmanThird {
    let type: ChessmanType
    let color: ChessmanColor
    var coordinates: (String, Int)?
    let figureSymbol: Character
    
    init(type: ChessmanType, color: ChessmanColor, figure: Character) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
    }
    
    init(type: ChessmanType, color: ChessmanColor, figure: Character, coordinates: (String, Int)) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
        self.setCoordinates(char: coordinates.0, num: coordinates.1) //Инициализатор передаёт аргументы в метод класса
    }
    
    func setCoordinates(char c: String, num n: Int) {
        self.coordinates = (c, n)
    }
    
    func kill() {
        self.coordinates = nil
    }
    
}


var queenBlack = ChessmanThird(type: .queen, color: .black, figure: "\u{2655}", coordinates: ("A", 6))




//Вложенные в класс типы
//Перечисления можно объявлять внутри классов, если они предназначены исключительно для этого класса

class NewChessMan {
    
    enum ChessType {
        case king, castle, bishop, pawn, knight, queen
    }
    
    enum ChessColor {
        case black, white
    }
    
    let type: ChessType
    let color: ChessColor
    var coordinates: (String, Int)?
    let figureSymbol: Character

    init(type: ChessType, color: ChessColor, figure: Character) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
    }
    
    init(type: ChessType, color: ChessColor, figure: Character, coordinates: (String, Int)) {
        self.type = type
        self.color = color
        self.figureSymbol = figure
        self.setCoordinates(char: coordinates.0, num: coordinates.1)
    }
    
    func setCoordinates(char c: String, num n: Int) {
        self.coordinates = (c, n)
    }
    
    func kill() {
        self.coordinates = nil
    }
    
}

let pawn = NewChessMan(type: .pawn, color: .white, figure: "\u{2323}", coordinates: ("B", 2))



//Ссылки на вложенные типы
//Получаем доступ к одному из членов перечисления ChessType, объявленного в конексте класса NewChessMan
var linkToEnumType = NewChessMan.ChessType.bishop










































































